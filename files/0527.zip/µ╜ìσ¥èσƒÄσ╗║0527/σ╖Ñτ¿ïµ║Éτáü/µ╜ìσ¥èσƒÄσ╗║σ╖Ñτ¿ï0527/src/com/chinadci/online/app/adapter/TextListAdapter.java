package com.chinadci.online.app.adapter;

import java.util.List;

import com.chinadci.online.app.R;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class TextListAdapter extends BaseAdapter{

	public static class TextModel{
		private String id;
		private String text;
		public TextModel(String id, String text) {
			super();
			this.id = id;
			this.text = text;
		}
		public String getId() {
			return id;
		}
		public String getText() {
			return text;
		}
	}
	
	private Context context;
	
	private List<TextModel> list;
	
	
	
	public TextListAdapter(Context context, List<TextModel> list) {
		super();
		this.context = context;
		this.list = list;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		
		TextModel model = list.get(position);
		
		if(convertView == null){
			convertView = LayoutInflater.from(context).inflate(
					R.layout.text_item, null);
		}
		
		((TextView)convertView.findViewById(R.id.text)).setText(model.text);
		
		return convertView;
	}

}
