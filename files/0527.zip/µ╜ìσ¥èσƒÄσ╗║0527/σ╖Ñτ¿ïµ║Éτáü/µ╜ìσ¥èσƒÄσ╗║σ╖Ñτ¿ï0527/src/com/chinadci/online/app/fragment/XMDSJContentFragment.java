package com.chinadci.online.app.fragment;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.chinadci.online.app.R;
import com.chinadci.online.app.adapter.TextListAdapter;
import com.chinadci.online.app.adapter.TextListAdapter.TextModel;
import com.chinadci.online.app.database.DataBaseHelper;
import com.chinadci.online.app.network.model.XMDSJ;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

public class XMDSJContentFragment extends Fragment{

	public static XMDSJContentFragment newInstance(String id){
		XMDSJContentFragment fragment = new XMDSJContentFragment();
		fragment.id = id;
		return fragment;
	}
	
	private ListView listView;
	
	private DataBaseHelper helper;
	
	private String id;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		listView = new ListView(getActivity());
		listView.setBackgroundResource(R.drawable.bg_radius_gray_border);
		
		return listView;
	}
	
	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onViewCreated(view, savedInstanceState);
		helper = new DataBaseHelper(getActivity());
		 
		
		try {
			load();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	private void load() throws SQLException{
		//for id
		List<TextModel> models = new ArrayList<TextListAdapter.TextModel>(); 
//		List<XMDSJ> list = helper.getXMDSJDao().queryForAll();
		List<XMDSJ> list = helper.getXMDSJDao().queryForEq("XMBH", id);
		for(XMDSJ xmdsj : list){
			models.add(new TextModel(xmdsj.PK, xmdsj.SJNR));
		}
		TextListAdapter adapter = new TextListAdapter(getActivity(), models);
		listView.setAdapter(adapter);
	}
	
}
