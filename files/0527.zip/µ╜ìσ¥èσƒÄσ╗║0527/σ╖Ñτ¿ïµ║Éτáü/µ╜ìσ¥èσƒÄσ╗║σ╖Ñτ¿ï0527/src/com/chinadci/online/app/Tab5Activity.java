package com.chinadci.online.app;

import com.chinadci.online.app.fragment.ProjectStarFragment;
import com.chinadci.online.app.fragment.ProjectZRRFragment;

import android.app.Activity;
import android.os.Bundle;

public class Tab5Activity extends BaseActivity{
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		switchFragment("all",new ProjectStarFragment());
	}

}
