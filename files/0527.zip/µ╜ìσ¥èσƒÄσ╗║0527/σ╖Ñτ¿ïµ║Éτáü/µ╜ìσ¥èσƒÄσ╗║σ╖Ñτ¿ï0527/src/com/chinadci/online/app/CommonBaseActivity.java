package com.chinadci.online.app;

import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.TextView;

public abstract class CommonBaseActivity extends FragmentActivity{

	
	
	@Override
	public void setContentView(int layoutResID) {
		
		setContentView(LayoutInflater.from(this).inflate(layoutResID,null));
		
	}
	
	@Override
	public void setContentView(View view) {
		setContentView(view,new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
	}
	@Override
	public void setContentView(View view, LayoutParams params) {
		super.setContentView(R.layout.common_activity);
		
		((ViewGroup)findViewById(R.id.frame_container)).addView(view);
		
		
		setWebTitle(getActionBarTitle());
		
		findViewById(R.id.frame_back).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				finish();
				
			}
		});
	}
	
	public void setWebTitle(String title){
		((TextView)findViewById(R.id.frame_title)).setText(title);
	}
	
	protected abstract String getActionBarTitle();
	
}
