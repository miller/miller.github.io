package com.chinadci.online.app;

import uk.co.senab.photoview.PhotoViewAttacher;

import com.chinadci.online.app.utils.BitmapLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.assist.ImageLoadingListener;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class PhotoViewActivity extends CommonBaseActivity{
	
	public static void open(Context context, String title,Uri uri){
		Intent intent = new Intent(context, PhotoViewActivity.class);
		intent.setData(uri);
		intent.putExtra("title", title);
		context.startActivity(intent);
	}
	
	private String title;
	
	private String uri;
	
	@Override
	protected void onCreate(Bundle bundle) {
		// TODO Auto-generated method stub
		super.onCreate(bundle);
		title = getIntent().getStringExtra("title");
		uri = getIntent().getDataString();
		
		setContentView(R.layout.photo_view);
		final ImageView imageView = (ImageView) findViewById(R.id.img);
		final View loadingView = findViewById(R.id.loading);
		BitmapLoader.getImageLoader(this).displayImage(uri,imageView,new ImageLoadingListener() {
			
			@Override
			public void onLoadingStarted(String imageUri, View view) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onLoadingFailed(String imageUri, View view,
					FailReason failReason) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
				loadingView.setVisibility(View.GONE);
				new PhotoViewAttacher(imageView).update();
				
			}
			
			@Override
			public void onLoadingCancelled(String imageUri, View view) {
				// TODO Auto-generated method stub
				
			}
		});
		
		
	}
	
	@Override
	protected String getActionBarTitle() {
		// TODO Auto-generated method stub
		return title;
	}
	
	

}
