package com.chinadci.online.app.network.model;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

//":["PK","XMBH","SJNR","SJSJ","ISDELETE","LASTUPDATE"],"
@DatabaseTable(tableName = "XMDSJ")
public class XMDSJ {
	@DatabaseField(id = true)
	public String PK;
	@DatabaseField
	public String XMBH;
	@DatabaseField
	public String SJNR;
	@DatabaseField
	public String SJSJ;
	@DatabaseField
	public String ISDELETE;
	@DatabaseField
	public String LASTUPDATE;
}
