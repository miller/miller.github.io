package com.chinadci.online.app;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;

import com.chinadci.online.app.adapter.GalleryListAdapter;
import com.chinadci.online.app.adapter.GalleryListAdapter.GalleryModel;
import com.chinadci.online.app.adapter.GalleryListAdapter.GalleryType;
import com.chinadci.online.app.network.UploadFileRequest;
import com.chinadci.online.app.utils.Configuration;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.GridView;
import android.widget.Toast;

public class UploadListActivity extends CommonBaseActivity implements OnClickListener{

	public static void open(Context context,String id){
		Intent intent = new Intent(context,UploadListActivity.class);
		intent.putExtra("id", id);
		context.startActivity(intent);
	}
	
	private GridView gridView;
	
	private String id;
	
	private GalleryListAdapter adapter;
	
	private List<GalleryModel> list = new ArrayList<GalleryModel>();
	
	@Override
	protected void onCreate(Bundle arg0) {
		// TODO Auto-generated method stub
		super.onCreate(arg0);
		id = getIntent().getStringExtra("id");
		setContentView(R.layout.upload_list_layout);
		findViewById(R.id.upload).setOnClickListener(this);
		gridView = (GridView) findViewById(R.id.gridview);
		load();
	}
	
	private void load(){
		list = new ArrayList<GalleryModel>();
		for(File file: Configuration.FILE_UPLOAD_CACHE.listFiles()){
			GalleryModel model = null;
			String ex = FilenameUtils.getExtension(file.toString());
			Uri uri = Uri.fromFile(file);
			if("jpg".equals(ex)){
				model = new GalleryModel(uri.toString());
			}else{
				model = new GalleryModel(uri.toString(), "");
			}
			list.add(model);
		}
		adapter = new GalleryListAdapter(this, list, true);
		gridView.setAdapter(adapter);
	}
	
	@Override
	protected String getActionBarTitle() {
		// TODO Auto-generated method stub
		return "影像资料本地上传列表";
	}
	
	
	
	private void onUpload(){
		
		final List<GalleryModel> uploadList = new ArrayList<GalleryModel>();
		for(GalleryModel model : list){
			if(model.isChecked()){
				uploadList.add(model);
			}
		}
		if(uploadList.size() == 0){
			Toast.makeText(this, "请选择上传媒体", Toast.LENGTH_SHORT).show();
			return;
		}
		final ProgressDialog dialog = ProgressDialog.show(this, "提示", "正在上传...",true);
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				for(GalleryModel uploadModel:uploadList){
					File file;
					if(uploadModel.getGalleryType()==GalleryType.PIC){
						Uri uri = Uri.parse(uploadModel.getPic());
						file = new File(uri.getPath());
						
					}else{
						Uri uri = Uri.parse(uploadModel.getVideourl());
						file = new File(uri.getPath());
					}
					
					UploadFileRequest uploadrequest = new UploadFileRequest(id, file);
					uploadrequest.request();
					String result = StringUtils.trim(uploadrequest.getResult()).toLowerCase();
					if(TextUtils.equals("ok",result )){
						file.delete();
					}
				}
				UploadListActivity.this.runOnUiThread(new Runnable() {
					
					@Override
					public void run() {
						load();
						
						dialog.dismiss();
						Toast.makeText(UploadListActivity.this, "上传成功", Toast.LENGTH_SHORT).show();
					}
				});
			}
		}).start();
		
		
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.upload:
			onUpload();
			break;

		default:
			break;
		}
		
	}

}
