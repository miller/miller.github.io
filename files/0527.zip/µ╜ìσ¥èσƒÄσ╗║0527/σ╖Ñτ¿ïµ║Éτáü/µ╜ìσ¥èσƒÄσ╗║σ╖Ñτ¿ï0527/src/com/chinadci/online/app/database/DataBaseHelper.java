package com.chinadci.online.app.database;

import java.sql.SQLException;

import com.chinadci.online.app.network.model.DSJSP;
import com.chinadci.online.app.network.model.PointRecord;
import com.chinadci.online.app.network.model.ShapeRecord;
import com.chinadci.online.app.network.model.XMDSJ;
import com.chinadci.online.app.network.model.XMFJZL;
import com.chinadci.online.app.network.model.XMLNJH;
import com.chinadci.online.app.network.model.XMXC;
import com.chinadci.online.app.network.model.XMZXJZ;
import com.chinadci.online.app.network.model.ZDXM;
import com.chinadci.online.app.network.model.ZLK;
import com.j256.ormlite.android.apptools.OrmLiteSqliteOpenHelper;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.dao.DaoManager;
import com.j256.ormlite.support.ConnectionSource;
import com.j256.ormlite.table.TableUtils;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

public class DataBaseHelper extends OrmLiteSqliteOpenHelper {

	private static final String DATABASE_NAME = "com.chinadci.online.app";

	private static final int DATABASE_VERSION = 1;

	public DataBaseHelper(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase arg0, ConnectionSource arg1) {
		try {
			TableUtils.createTableIfNotExists(connectionSource, ZDXM.class);
			TableUtils.createTableIfNotExists(connectionSource, XMFJZL.class);
			TableUtils.createTableIfNotExists(connectionSource, ZLK.class);
			TableUtils.createTableIfNotExists(connectionSource,
					PointRecord.class);
			TableUtils.createTableIfNotExists(connectionSource,
					ShapeRecord.class);
			TableUtils.createTableIfNotExists(connectionSource,
					XMDSJ.class);
			TableUtils.createTableIfNotExists(connectionSource,
					XMXC.class);
			TableUtils.createTableIfNotExists(connectionSource,
					XMZXJZ.class);
			TableUtils.createTableIfNotExists(connectionSource,
					DSJSP.class);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void onUpgrade(SQLiteDatabase database, ConnectionSource arg1,
			int arg2, int arg3) {
		try {
			TableUtils.dropTable(connectionSource, ZDXM.class, true);
			TableUtils.dropTable(connectionSource, XMFJZL.class, true);
			TableUtils.dropTable(connectionSource, ZLK.class, true);
			TableUtils.dropTable(connectionSource, PointRecord.class, true);
			TableUtils.dropTable(connectionSource, ShapeRecord.class, true);
			TableUtils.dropTable(connectionSource, XMDSJ.class, true);
			TableUtils.dropTable(connectionSource, XMXC.class, true);
			TableUtils.dropTable(connectionSource, XMZXJZ.class, true);
			TableUtils.dropTable(connectionSource, DSJSP.class, true);
			onCreate(database, connectionSource);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private Dao<ZDXM, String> ZDXMDao;

	public Dao<ZDXM, String> getZDXMDao() throws SQLException {
		if (ZDXMDao == null) {
			ZDXMDao = DaoManager.createDao(getConnectionSource(), ZDXM.class);
		}
		return ZDXMDao;
	}

	private Dao<XMFJZL, String> XMFJZLDao;

	public Dao<XMFJZL, String> getXMFJZLDao() throws SQLException {
		if (XMFJZLDao == null) {
			XMFJZLDao = DaoManager.createDao(getConnectionSource(),
					XMFJZL.class);
		}
		return XMFJZLDao;
	}

	private Dao<DSJSP, String> DSJSPDao;

	public Dao<DSJSP, String> getDSJSPDao() throws SQLException {
		if (DSJSPDao == null) {
			DSJSPDao = DaoManager.createDao(getConnectionSource(), DSJSP.class);
		}
		return DSJSPDao;
	}

	private Dao<XMLNJH, String> XMLNJHDao;

	public Dao<XMLNJH, String> getXMLNJHDao() throws SQLException {
		if (XMLNJHDao == null) {
			XMLNJHDao = DaoManager.createDao(getConnectionSource(),
					XMLNJH.class);
		}
		return XMLNJHDao;
	}

	private Dao<XMZXJZ, String> XMZXJZDao;

	public Dao<XMZXJZ, String> getXMZXJZDao() throws SQLException {
		if (XMZXJZDao == null) {
			XMZXJZDao = DaoManager.createDao(getConnectionSource(),
					XMZXJZ.class);
		}
		return XMZXJZDao;
	}

	private Dao<ZLK, String> ZLKDao;

	public Dao<ZLK, String> getZLKDao() throws SQLException {
		if (ZLKDao == null) {
			ZLKDao = DaoManager.createDao(getConnectionSource(), ZLK.class);
		}
		return ZLKDao;
	}

	private Dao<ShapeRecord, String> ShapeRecordDao;

	public Dao<ShapeRecord, String> getShapeRecordDao() throws SQLException {
		if (ShapeRecordDao == null) {
			ShapeRecordDao = DaoManager.createDao(getConnectionSource(),
					ShapeRecord.class);
		}
		return ShapeRecordDao;
	}

	private Dao<PointRecord, String> PointRecordDao;

	public Dao<PointRecord, String> getPointRecordDao() throws SQLException {
		if (PointRecordDao == null) {
			PointRecordDao = DaoManager.createDao(getConnectionSource(),
					PointRecord.class);
		}
		return PointRecordDao;
	}
	
	private Dao<XMDSJ, String> XMDSJDao;

	public Dao<XMDSJ, String> getXMDSJDao() throws SQLException {
		if (XMDSJDao == null) {
			XMDSJDao = DaoManager.createDao(getConnectionSource(),
					XMDSJ.class);
		}
		return XMDSJDao;
	}
	
	private Dao<XMXC, String> XMXCDao;

	public Dao<XMXC, String> getXMXCDao() throws SQLException {
		if (XMXCDao == null) {
			XMXCDao = DaoManager.createDao(getConnectionSource(),
					XMXC.class);
		}
		return XMXCDao;
	}

}
