package com.chinadci.online.app;

import java.util.ArrayList;
import java.util.List;

import com.chinadci.online.app.adapter.GalleryListAdapter.GalleryModel;
import com.chinadci.online.app.adapter.GalleryListAdapter.GalleryType;
import com.chinadci.online.app.utils.BitmapLoader;

import uk.co.senab.photoview.PhotoView;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.LayoutParams;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class SliderActivity extends CommonBaseActivity {
	
	public static void open(Context context,ArrayList<GalleryModel> list,int pos){
		Intent intent = new Intent(context, SliderActivity.class);
		intent.putExtra("list", list);
		intent.putExtra("pos", pos);
		context.startActivity(intent);
	}
	
	private ArrayList<GalleryModel> list;
	
	private int pos;
	
	private ViewPager mViewPager;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		list = (ArrayList<GalleryModel>) getIntent().getSerializableExtra("list");
		pos = getIntent().getIntExtra("pos", 0);
		setContentView(R.layout.slider_layout);
		ViewPager viewPager = (ViewPager) findViewById(R.id.view_pager);
		viewPager.setAdapter(new SamplePagerAdapter(this, list));
		viewPager.setCurrentItem(pos);
	 
	}

	@Override
	protected String getActionBarTitle() {
		// TODO Auto-generated method stub
		return "影像资料";
	}

	static class SamplePagerAdapter extends PagerAdapter {

		private Context context;
		
		private List<GalleryModel> list;

		
		public SamplePagerAdapter(Context context, List<GalleryModel> list) {
			super();
			this.context = context;
			this.list = list;
		}

		@Override
		public int getCount() {
			return list.size();
		}

		@Override
		public View instantiateItem(ViewGroup container, int position) {
			GalleryModel model = list.get(position);
			View view = LayoutInflater.from(context).inflate(
					R.layout.slider_item, null);
			
			ViewHolder holder = new ViewHolder(view);
			holder.photoView.setImageResource(R.drawable.placeholder);
			if(model.getGalleryType() == GalleryType.PIC){
				holder.photoView.setVisibility(View.VISIBLE);
				BitmapLoader.displayImage(context, model.getPic(), holder.photoView);
				holder.holder.setVisibility(View.GONE);
			}else{
				
				Bitmap bitmap = ThumbnailUtils.createVideoThumbnail(Uri.parse(model.getVideourl()).getPath(),
		                MediaStore.Images.Thumbnails.MINI_KIND);
				if(bitmap != null){
					holder.photoView.setImageBitmap(bitmap);
				}
					
				holder.holder.setVisibility(View.VISIBLE);

			}
			
			

			// Now just add PhotoView to ViewPager and return it
			container.addView(view, LayoutParams.MATCH_PARENT,
					LayoutParams.MATCH_PARENT);

			return view;
		}

		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {
			container.removeView((View) object);
		}

		@Override
		public boolean isViewFromObject(View view, Object object) {
			return view == object;
		}
		
		private class ViewHolder{
			private PhotoView photoView;
			private View holder;
			public ViewHolder(View view) {
				photoView = (PhotoView) view.findViewById(R.id.photoview);
				holder = view.findViewById(R.id.video);
			}
		}

	}

}
