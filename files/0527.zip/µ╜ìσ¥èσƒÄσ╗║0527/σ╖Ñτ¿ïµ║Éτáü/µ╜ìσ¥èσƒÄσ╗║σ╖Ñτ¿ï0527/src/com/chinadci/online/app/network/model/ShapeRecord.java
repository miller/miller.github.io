package com.chinadci.online.app.network.model;

import java.util.ArrayList;

import org.apache.commons.lang3.StringUtils;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;
import com.tianditu.android.maps.GeoPoint;

//PROJECTID, UPDATETIME, DELETEDS02, PRJYEAR, IsHistory
@DatabaseTable(tableName = "ShapeRecord")
public class ShapeRecord {

	
	@DatabaseField(id = true)
	private String PROJECTID;
	
	@DatabaseField
	private String points;

	private String name;
	
	
	
	public ShapeRecord(String pROJECTID,String name, String points) {
		super();
		PROJECTID = pROJECTID;
		this.points = points;
	}

	public ShapeRecord(String pROJECTID, ArrayList<GeoPoint> geoPoints) {
		super();
		PROJECTID = pROJECTID;
		ArrayList<String> list = new ArrayList<String>();
		for(GeoPoint point:geoPoints){
			list.add(point.getLatitudeE6()+","+point.getLongitudeE6());
		}
		points = StringUtils.join(list, ':');
	}
	
	public ShapeRecord() {
		
	}
	
	public ArrayList<GeoPoint> getGeoPoints() {
		ArrayList<GeoPoint> list = new ArrayList<GeoPoint>();
		
		for(String row : StringUtils.split(points,':')){
			String[] cols = StringUtils.split(row,',');
			list.add(new GeoPoint(Integer.parseInt(cols[0]), Integer.parseInt(cols[1])));
		}
		
		return list;
	}
	public String getPROJECTID() {
		return PROJECTID;
	}
	public String getName() {
		return name;
	}
	
}
