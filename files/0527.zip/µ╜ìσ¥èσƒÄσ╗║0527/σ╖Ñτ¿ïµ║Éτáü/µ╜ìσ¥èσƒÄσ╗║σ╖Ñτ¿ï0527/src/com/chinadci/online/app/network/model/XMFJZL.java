package com.chinadci.online.app.network.model;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;


@DatabaseTable(tableName = "XMFJZL")
public class XMFJZL {

	@DatabaseField(id = true)
	public String PK;
	@DatabaseField(columnName="XMBH")
	public String XMBH;
	@DatabaseField
	public String FJM;
	@DatabaseField
	public String FLM;
	@DatabaseField
	public String FJLX;
	@DatabaseField
	public String ZLBH;
	@DatabaseField
	public String PXH;
	@DatabaseField
	public String ISDELETE;
	@DatabaseField
	public String LASTUPDATE;
	
}
