package com.chinadci.online.app.fragment;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import android.content.Context;

import com.chinadci.online.app.fragment.CommonItemFragment.Status1;
import com.chinadci.online.app.network.model.ZDXM;
import com.j256.ormlite.stmt.Where;

public class ProjectLeibieCurrentFragment extends CommonItemFragment {

	@Override
	public List<ZDXM> onChange(String text) {
		List<ZDXM> list = new ArrayList<ZDXM>();
		try {
			Where<ZDXM, String> where = helper.getZDXMDao().queryBuilder().orderBy("PXH", true)
					.where().like("XMLB", "%"+text+"%");
			where.and();
			buildStatus(where,Status1.CURRENT);
			list = where.query();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	@Override
	protected String[] getWheelList(Context context) {
		String[] list = null;
		try {
			List<String[]> res = helper.getZDXMDao().queryRaw("select XMLB,count(*) as count from ZDXM where JSJD != '完工' group by XMLB having count > 0 and XMLB != ''").getResults();
			list = new String[res.size()];
			
			for(int i = 0;i<list.length;i++){
				list[i] = res.get(i)[0];
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	@Override
	protected Status1 getStatus1() {
		// TODO Auto-generated method stub
		return Status1.CURRENT;
	}

}
