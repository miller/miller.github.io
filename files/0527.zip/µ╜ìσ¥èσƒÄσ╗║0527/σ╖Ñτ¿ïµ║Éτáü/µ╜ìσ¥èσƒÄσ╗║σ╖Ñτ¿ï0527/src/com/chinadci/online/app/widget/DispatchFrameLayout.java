package com.chinadci.online.app.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.FrameLayout;

public class DispatchFrameLayout extends FrameLayout{

	public static interface  OnDispatchTouchEvent{
		public boolean dispatchTouchEvent(MotionEvent ev);
	}
	private OnDispatchTouchEvent onDispatchTouchEvent;
	public DispatchFrameLayout(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		// TODO Auto-generated constructor stub
	}

	public DispatchFrameLayout(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
	}

	public void setOnDispatchTouchEvent(
			OnDispatchTouchEvent onDispatchTouchEvent) {
		this.onDispatchTouchEvent = onDispatchTouchEvent;
	}
	public DispatchFrameLayout(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}
	
	
	@Override
	public boolean onInterceptTouchEvent(MotionEvent ev) {
		if(onDispatchTouchEvent != null){
			return onDispatchTouchEvent.dispatchTouchEvent(ev);
		}
		return super.onInterceptTouchEvent(ev);
	}
	

}
