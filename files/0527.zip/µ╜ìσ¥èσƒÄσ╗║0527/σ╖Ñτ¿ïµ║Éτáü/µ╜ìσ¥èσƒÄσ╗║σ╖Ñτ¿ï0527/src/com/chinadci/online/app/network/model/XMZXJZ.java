package com.chinadci.online.app.network.model;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable(tableName = "XMZXJZ")
public class XMZXJZ {
	@DatabaseField(id = true)
	public String PK;
	@DatabaseField
	public String XMBH;
	@DatabaseField
	public String JLLX;
	@DatabaseField
	public String JLNR;
	@DatabaseField
	public String PXH;
	@DatabaseField
	public String ISDELETE;
	@DatabaseField
	public String LASTUPDATE;
}
