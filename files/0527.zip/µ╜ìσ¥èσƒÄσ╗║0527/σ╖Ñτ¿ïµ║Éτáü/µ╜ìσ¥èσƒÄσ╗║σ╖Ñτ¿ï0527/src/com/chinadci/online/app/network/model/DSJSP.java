package com.chinadci.online.app.network.model;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable(tableName = "DSJSP")
public class DSJSP {

	@DatabaseField(id = true)
	public String PK;
	@DatabaseField
	public String SJBH;
	@DatabaseField
	public String ZLBH;
	@DatabaseField
	public String PXH;
	@DatabaseField
	public String ISDELETE;
	@DatabaseField
	public String LASTUPDATE;
	
}
