package com.chinadci.online.app;

import com.chinadci.online.app.fragment.AllProjectFragment;
import com.chinadci.online.app.fragment.FileListFragment;
import com.chinadci.online.app.network.Request;
import com.chinadci.online.app.network.RequestAsync;
import com.chinadci.online.app.network.RequestAsync.Async;
import com.chinadci.online.app.network.ZDXMRequest;
import com.chinadci.online.app.network.ZDXMRequest.Params;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;

public class Tab1Activity extends BaseActivity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
//		switchFragment("all",AllProjectFragment.newInstance());
		switchFragment("all",FileListFragment.newInstance());
	}
	
}
