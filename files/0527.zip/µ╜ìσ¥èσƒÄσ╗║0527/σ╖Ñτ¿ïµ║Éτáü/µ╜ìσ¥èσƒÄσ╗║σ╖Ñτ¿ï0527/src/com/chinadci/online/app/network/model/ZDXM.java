package com.chinadci.online.app.network.model;

import java.util.ArrayList;
import java.util.List;

import com.chinadci.online.app.adapter.ProjectListAdapter.Project;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable(tableName = "ZDXM")
public class ZDXM {

	@DatabaseField(id = true)
	public String PK;

	@DatabaseField
	public String XMBH;

	@DatabaseField(columnName="XMMC")
	public String XMMC;

	@DatabaseField(columnName="XMLB")
	public String XMLB;

	@DatabaseField
	public String QSSJ;

	@DatabaseField
	public String ZZSJ;

	@DatabaseField
	public String ZTZ;
	@DatabaseField
	public String JSJD;
	@DatabaseField
	public String JSNR;
	@DatabaseField
	public String FGSLD;
	@DatabaseField
	public String ZRR;
	@DatabaseField
	public String XTSLD;
	@DatabaseField
	public String XGLD;
	@DatabaseField
	public String QTZRDW;
	@DatabaseField
	public String SDZRDW;
	@DatabaseField
	public String JSDW;
	@DatabaseField
	public String XMJB;
	@DatabaseField
	public String LXBP;
	@DatabaseField
	public String GHXZBP;
	@DatabaseField
	public String YDSXBP;
	@DatabaseField
	public String HJYXPJBP;
	@DatabaseField
	public String FHXKSXBP;
	@DatabaseField
	public String ZDCQWCSJ;
	@DatabaseField
	public String YDQK;
	@DatabaseField
	public String SGZBSJ;
	@DatabaseField
	public String KGSJ;
	@DatabaseField
	public String WGSJ;
	@DatabaseField
	public String FMZ;
	@DatabaseField
	public String JHAP;
	@DatabaseField
	public String NDTZ;
	@DatabaseField
	public Integer PXH;
	@DatabaseField
	public String BZ;
	@DatabaseField
	public String ISDELETE;
	@DatabaseField
	public String LASTUPDATE;
	@DatabaseField
	public boolean stared;
	
	public Project toProject(){
		Project project = new Project(PK,JSJD, XMMC, stared);
		return project;
	}
	
	public static List<Project> toProjectList(List<ZDXM> list){
		List<Project> list2 = new ArrayList<Project>();
		for(ZDXM zdxm:list){
			list2.add(zdxm.toProject());
		}
		return list2;
	}
	
}
