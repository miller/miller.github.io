package com.chinadci.online.app.utils;

import java.sql.SQLException;

import com.chinadci.online.app.database.DataBaseHelper;
import com.chinadci.online.app.network.model.ZDXM;

import android.content.Context;

public class DatabaseUtils {

	public static void stared(Context context,String id,boolean stared) throws SQLException{
		DataBaseHelper baseHelper = new DataBaseHelper(context);
		ZDXM zdxm = baseHelper.getZDXMDao().queryForId(id);
		zdxm.stared = stared;
		baseHelper.getZDXMDao().update(zdxm);
	}
	
}
