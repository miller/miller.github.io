package com.chinadci.online.app.network.model;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import com.chinadci.online.app.network.ShapeCheckRequest;
import com.chinadci.online.app.utils.Configuration;

import android.content.Context;
import android.os.Environment;

public class GeoFileDownloadRequest {

	
	
	private static final String HOST = "http://119.191.58.252:809/WFZDXM/GeoData/";
	
	public void download(Context context){
		ShapeCheckRequest check0Request = new ShapeCheckRequest(new ShapeCheckRequest.Params(context,0));
		check0Request.request();
		if(check0Request.isHasNew()){
			download2(HOST+"zdxm_point.shp", "zdxm_point.shp");
			download2(HOST+"zdxm_point.dbf", "zdxm_point.dbf");
			download2(HOST+"zdxm_point.shx", "zdxm_point.shx");
		}
		
		ShapeCheckRequest check1Request = new ShapeCheckRequest(new ShapeCheckRequest.Params(context,2));
		check1Request.request();
		if(check1Request.isHasNew()){
			download2(HOST+"zdxm_polygon.shp", "zdxm_polygon.shp");
			download2(HOST+"zdxm_polygon.dbf", "zdxm_polygon.dbf");
			download2(HOST+"zdxm_polygon.shx", "zdxm_polygon.shx");
		}
		
		
	}
	
	private void download2(String strurl,String filename){
		InputStream input = null;
        OutputStream output = null;
        HttpURLConnection connection = null;
        try {
            URL url = new URL(strurl);
            connection = (HttpURLConnection) url.openConnection();
            connection.connect();

            // expect HTTP 200 OK, so we don't mistakenly save error report
            // instead of the file
            if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
                System.err.println("Server returned HTTP " + connection.getResponseCode()
                        + " " + connection.getResponseMessage()) ;
                return;
            }

            // download the file
            input = connection.getInputStream();
            File file = new File(Configuration.FOLDER,filename);
            if(!file.exists()){
            	file.createNewFile();
            }
            output = new FileOutputStream( file);

            byte data[] = new byte[4096];
            int count;
            while ((count = input.read(data)) != -1) {
                // allow canceling with back button
              
              
               
                output.write(data, 0, count);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (output != null)
                    output.close();
                if (input != null)
                    input.close();
            } catch (IOException ignored) {
            }

            if (connection != null)
                connection.disconnect();
        }
	}
	
	private void download(String strurl,String filename) {
		try {
			
			URL url = new URL(strurl);

			
			HttpURLConnection urlConnection = (HttpURLConnection) url
					.openConnection();

			
			urlConnection.setRequestMethod("GET");
//			urlConnection.setDoOutput(true);

			
			urlConnection.connect();

			
		
			File file = new File(Configuration.FOLDER, filename);

			
			FileOutputStream fileOutput = new FileOutputStream(file);

			
			InputStream inputStream = urlConnection.getInputStream();

	

			
			byte[] buffer = new byte[1024];
			int bufferLength = 0; 
			while ((bufferLength = inputStream.read(buffer)) > 0) {
				
				fileOutput.write(buffer, 0, bufferLength);
	
				

			}
			// close the output stream when done
			fileOutput.close();

		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
