package com.chinadci.online.app.adapter;

import java.sql.SQLException;
import java.util.List;

import com.chinadci.online.app.MapViewDemo;
import com.chinadci.online.app.ProjectDetailActivity;
import com.chinadci.online.app.R;
import com.chinadci.online.app.utils.DatabaseUtils;
import com.chinadci.online.app.widget.MyMapView;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class ProjectListAdapter extends BaseAdapter {
	

	public static class Project {

		private String id;

		private String status;

		private String name;

		private boolean stared;

		public Project(String id, String status, String name, boolean stared) {
			super();
			this.id = id;
			this.status = status;
			this.name = name;
			this.stared = stared;
		}
		
		public String getId() {
			return id;
		}

		public int getStatusIcon() {
			int res = R.drawable.icon_home_selected;
			
			Integer integer = MyMapView.TYPEMAP.get(status);
			
			if(integer != null){
				res = integer;
			}
			
			return res;

		}

	}

	private Context context;

	private List<Project> list;

	public ProjectListAdapter(Context context, List<Project> list) {
		super();
		this.context = context;
		this.list = list;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		final Project project = list.get(position);
		ViewHolder holder;
		if (convertView == null) {
			convertView = LayoutInflater.from(context).inflate(
					R.layout.project_item, null);
			holder = new ViewHolder(convertView);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		convertView.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				MapViewDemo.open(context, project.id);
				
			}
		});
		holder.starNext.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				ProjectDetailActivity.open(context, project.id);
				
			}
		});
		holder.statusView.setImageResource(project.getStatusIcon());
		holder.textView.setText(project.name);
		holder.starBtn.setSelected(project.stared);
		final View starBtn = holder.starBtn;
		holder.starBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				starBtn.setSelected(!starBtn.isSelected());
				try {
					DatabaseUtils.stared(context, project.id, starBtn.isSelected());
					project.stared = starBtn.isSelected();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		});
		
		return convertView;
	}

	public static class ViewHolder {
		private ImageView statusView;
		private TextView textView;
		private View starBtn;
		private View starNext;

		public ViewHolder(View view) {
			statusView = (ImageView) view.findViewById(R.id.status);
			textView = (TextView) view.findViewById(R.id.text);
			starBtn = view.findViewById(R.id.btn_star);
			starNext = view.findViewById(R.id.btn_next);
			
		}
	}

}
