package com.chinadci.online.app.network.model;

//":["PK","XMBH","SSNF","ZSNDLJWCTZ","YJDJHTZ","EJDJHTZ","SJDJHTZ","SIJDJHTZ","NDYSBJHTZ","NDJHTZ","NDJSNR","BZ","ISDELETE","LASTUPDATE"],"
public class XMLNJH {

	public String PK;

	public String XMBH;

	public String SSNF;

	public String ZSNDLJWCTZ;

	public String YJDJHTZ;

	public String EJDJHTZ;

	public String SJDJHTZ;

	public String SIJDJHTZ;

	public String NDYSBJHTZ;

	public String NDJHTZ;

	public String NDJSNR;

	public String BZ;

	public String ISDELETE;

	public String LASTUPDATE;
}
