package com.chinadci.online.app.network;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FilenameUtils;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import android.net.Uri;
import android.webkit.MimeTypeMap;

public class UploadFileRequest extends Request2{

	private String prjid;
	
	private File file;
	
	private String creator = "ue001";
	
	
	
	public UploadFileRequest(String prjid, File file) {
		super();
		this.prjid = prjid;
		this.file = file;
	}
	
	private String result;

	@Override
	public void onSuccess(String data) {
		result = data;
	}
	
	public String getResult() {
		return result;
	}

	@Override
	public void onError(int code, String msg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onResultError(int code, String msg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onServerError(int code, String msg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getURL() {
		// TODO Auto-generated method stub
		return HOST+"file/upload?prjid="+prjid;
	}

	@Override
	public List<NameValuePair> fillParams() {
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("creator", creator));
		return params;
	}
	
	@Override
	protected List<BinaryBody> fillFiles() {
		String extend = MimeTypeMap.getFileExtensionFromUrl((Uri.fromFile(file).toString()));
		String mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extend);
		
		BinaryBody body = new BinaryBody("file", file, mimeType, FilenameUtils.getName(file.toString()));
		List<BinaryBody> list = new ArrayList<BinaryBody>();
		list.add(body);
		return list;
	}

}
