package com.chinadci.online.app.adapter;

import java.util.ArrayList;
import java.util.List;

import com.chinadci.online.app.R;
import com.chinadci.online.app.network.model.XMFJZL;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class ProjectAttachListAdapter extends BaseAdapter{

	public static interface OnAttachClickListner{
		public void onClick(ProjectAttach attach);
	}
	
	public static class ProjectAttach{
		public String id;
		public String type;
		public String name;
		public ProjectAttach(String id, String type, String name) {
			super();
			this.id = id;
			this.type = type;
			this.name = name;
		}
		
	}
	
	public static class ProjectAttachGroup{
		private String title;
		private List<ProjectAttach> list;
		public ProjectAttachGroup(String title, List<ProjectAttach> list) {
			super();
			this.title = title;
			this.list = list;
		}
		
		public static List<ProjectAttachGroup> toProjectAttachGroup(List<XMFJZL> list){
			
			List<ProjectAttachGroup> res = new ArrayList<ProjectAttachListAdapter.ProjectAttachGroup>();
			
			for(XMFJZL xmfjzl : list ){
				List<ProjectAttach> attachGroup = null;
				for(ProjectAttachGroup group:res){
					if(TextUtils.equals(group.title, xmfjzl.FLM)){
						attachGroup = group.list;
						break;
					}
				}
				
				if(attachGroup == null){
					attachGroup = new ArrayList<ProjectAttachListAdapter.ProjectAttach>();
					res.add(new ProjectAttachGroup(xmfjzl.FLM, attachGroup));
				}
				
				attachGroup.add(new ProjectAttach(xmfjzl.PK, xmfjzl.FJLX, xmfjzl.FJM));
				
			}
			return res;
			
		}
		
	}
	
	private Context context;
	
	private List<ProjectAttachGroup> list;
	
	private OnAttachClickListner attachClickListner;
	
	
	public ProjectAttachListAdapter(Context context,
			List<ProjectAttachGroup> list,OnAttachClickListner attachClickListner) {
		super();
		this.context = context;
		this.list = list;
		this.attachClickListner = attachClickListner;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		ProjectAttachGroup group = list.get(position);
		if(convertView == null){
			convertView = LayoutInflater.from(context).inflate(
					R.layout.project_attach_group, null);
			holder = new ViewHolder(convertView);
			convertView.setTag(holder);
		}else{
			holder = (ViewHolder) convertView.getTag();
		}
		holder.add(group.list);
		
		holder.titleView.setText(group.title);
		return convertView;
		
	}
	
	
	private class ViewHolder{
		
		private ViewGroup viewGroup;
		
		private TextView titleView;
		
		public ViewHolder(View view) {
			viewGroup = (ViewGroup) view.findViewById(R.id.container);
			titleView = (TextView) view.findViewById(R.id.title);
		}
		
		public void add(List<ProjectAttach> list){
			viewGroup.removeAllViews();
			int i = 0;
			for(final ProjectAttach attach : list){
				View view = LayoutInflater.from(context).inflate(R.layout.project_attach_item, null);
				view.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						attachClickListner.onClick(attach);
						
					}
				});
				View sep = view.findViewById(R.id.sep);
				if(i != list.size()-1){
					sep.setVisibility(View.VISIBLE);
				}else{
					sep.setVisibility(View.GONE);
				}
				TextView textView = (TextView) view.findViewById(R.id.name);
				textView.setText(attach.name);
				viewGroup.addView(view);
				i++;
			}
			
			
		}
		
	}
	
	

}
