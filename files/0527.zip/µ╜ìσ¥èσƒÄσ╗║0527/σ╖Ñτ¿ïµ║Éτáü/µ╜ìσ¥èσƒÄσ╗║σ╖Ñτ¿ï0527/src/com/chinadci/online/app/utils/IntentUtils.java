package com.chinadci.online.app.utils;

import java.io.File;

import com.chinadci.online.app.PhotoViewActivity;
import com.chinadci.online.app.network.DownloadFileRequest;
import com.chinadci.online.app.network.DownloadFileRequest.Callback;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;

public class IntentUtils {

	
	
	// android获取一个用于打开HTML文件的intent
	private static Intent getHtmlFileIntent(String param) {
		Uri uri = Uri.parse(param).buildUpon()
				.encodedAuthority("com.android.htmlfileprovider")
				.scheme("content").encodedPath(param).build();
		Intent intent = new Intent("android.intent.action.VIEW");
		intent.setDataAndType(uri, "text/html");
		return intent;
	}
	
	public static void startImageActivity(Context context,String title, Uri uri){
		PhotoViewActivity.open(context, title, uri);
		/*Intent intent = getImageFileIntent(uri);
		try{
			context.startActivity(intent);
		}catch(ActivityNotFoundException e){
			Toast.makeText(context, "请安装Image应用.", Toast.LENGTH_LONG).show();
		}*/
	}

	// android获取一个用于打开图片文件的intent
	private static Intent getImageFileIntent(Uri uri) {
		Intent intent = new Intent("android.intent.action.VIEW");
		intent.addCategory("android.intent.category.DEFAULT");
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		
		intent.setDataAndType(uri, "image/*");
		return intent;
	}
	
	
	private static void _startPdfActivity(Context context, Uri uri){
		Intent intent = getPdfFileIntent(uri);
		try{
			context.startActivity(intent);
		}catch(ActivityNotFoundException e){
			Toast.makeText(context, "请安装Pdf应用.", Toast.LENGTH_LONG).show();
		}
	}
	
	public static void startPdfActivity(final Context context, Uri uri){
		if(uri.toString().startsWith("http://")){
			new DownloadFileRequest(context, uri.toString(), new Callback() {
				
				@Override
				public void onload(File file) {
					_startPdfActivity(context,Uri.fromFile(file));
					
				}
			}).download();
		}else{
			_startPdfActivity(context,uri);
		}
		
	}
	
	// android获取一个用于打开PDF文件的intent
	private static Intent getPdfFileIntent(Uri uri) {
		Intent intent = new Intent("android.intent.action.VIEW");
		intent.addCategory("android.intent.category.DEFAULT");
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setDataAndType(uri, "application/pdf");
		return intent;
	}
	
	public static void startTextActivity(Context context, String param){
		Intent intent = getTextFileIntent(param,false);
		try{
			context.startActivity(intent);
		}catch(ActivityNotFoundException e){
			Toast.makeText(context, "请安装Text应用.", Toast.LENGTH_LONG).show();
		}
	}

	// android获取一个用于打开文本文件的intent
	private static Intent getTextFileIntent(String param, boolean paramBoolean) {
		Intent intent = new Intent("android.intent.action.VIEW");
		intent.addCategory("android.intent.category.DEFAULT");
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		if (paramBoolean) {
			Uri uri1 = Uri.parse(param);
			intent.setDataAndType(uri1, "text/plain");
		} else {
			Uri uri2 = Uri.fromFile(new File(param));
			intent.setDataAndType(uri2, "text/plain");
		}
		return intent;
	}
	
	public static void startAudioActivity(Context context, String param){
		Intent intent = getAudioFileIntent(param);
		try{
			context.startActivity(intent);
		}catch(ActivityNotFoundException e){
			Toast.makeText(context, "请安装Audio应用.", Toast.LENGTH_LONG).show();
		}
	}

	// android获取一个用于打开音频文件的intent
	private static Intent getAudioFileIntent(String param) {
		Intent intent = new Intent("android.intent.action.VIEW");
		intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		intent.putExtra("oneshot", 0);
		intent.putExtra("configchange", 0);
		Uri uri = Uri.fromFile(new File(param));
		intent.setDataAndType(uri, "audio/*");
		return intent;
	}
	
	public static void startVideoActivity(Context context, Uri uri){
		Intent intent = getVideoFileIntent(uri);
		try{
			context.startActivity(intent);
		}catch(ActivityNotFoundException e){
			Toast.makeText(context, "请安装Video应用.", Toast.LENGTH_LONG).show();
		}
	}

	// android获取一个用于打开视频文件的intent
	private static Intent getVideoFileIntent(Uri uri) {
		Intent intent = new Intent("android.intent.action.VIEW");
		intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		intent.putExtra("oneshot", 0);
		intent.putExtra("configchange", 0);
	
		intent.setDataAndType(uri, "video/*");
		return intent;
	}

	// android获取一个用于打开CHM文件的intent
	private static Intent getChmFileIntent(String param) {
		Intent intent = new Intent("android.intent.action.VIEW");
		intent.addCategory("android.intent.category.DEFAULT");
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		Uri uri = Uri.fromFile(new File(param));
		intent.setDataAndType(uri, "application/x-chm");
		return intent;
	}
	
	private static void _startWordActivity(Context context,Uri uri){
		Intent intent = getWordFileIntent(uri);
		try{
			context.startActivity(intent);
		}catch(ActivityNotFoundException e){
			Toast.makeText(context, "请安装word应用.", Toast.LENGTH_LONG).show();
		}
	}

	public static void startWordActivity(final Context context, final Uri uri){
		if(uri.toString().startsWith("http://")){
			new DownloadFileRequest(context, uri.toString(), new Callback() {
				
				@Override
				public void onload(File file) {
					_startWordActivity(context,Uri.fromFile(file));
					
				}
			}).download();
		}else{
			_startWordActivity(context,uri);
		}
		
		
	}
	
	// android获取一个用于打开Word文件的intent
	private static Intent getWordFileIntent(Uri uri) {
		Intent intent = new Intent("android.intent.action.VIEW");
		intent.addCategory("android.intent.category.DEFAULT");
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setDataAndType(uri, "application/msword");
		return intent;
	}
	
	public static void startExcelActivity(final Context context, Uri uri){
		if(uri.toString().startsWith("http://")){
			new DownloadFileRequest(context, uri.toString(), new Callback() {
				
				@Override
				public void onload(File file) {
					_startExcelActivity(context,Uri.fromFile(file));
					
				}
			}).download();
		}else{
			_startExcelActivity(context,uri);
		}
		
	}
	
	private static void _startExcelActivity(Context context, Uri uri){
		Intent intent = getExcelFileIntent(uri);
		try{
			context.startActivity(intent);
		}catch(ActivityNotFoundException e){
			Toast.makeText(context, "请安装Excel应用.", Toast.LENGTH_LONG).show();
		}
	}

	// android获取一个用于打开Excel文件的intent
	private static Intent getExcelFileIntent(Uri uri) {
		Intent intent = new Intent("android.intent.action.VIEW");
		intent.addCategory("android.intent.category.DEFAULT");
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setDataAndType(uri, "application/vnd.ms-excel");
		return intent;
	}
	
	public static void startPptActivity(final Context context, Uri uri){
		if(uri.toString().startsWith("http://")){
			new DownloadFileRequest(context, uri.toString(), new Callback() {
				
				@Override
				public void onload(File file) {
					_startPptActivity(context,Uri.fromFile(file));
					
				}
			}).download();
		}else{
			_startPptActivity(context,uri);
		}
		
	}
	
	private static void _startPptActivity(Context context, Uri uri){
		Intent intent = getPptFileIntent(uri);
		try{
			context.startActivity(intent);
		}catch(ActivityNotFoundException e){
			Toast.makeText(context, "请安装Ppt应用.", Toast.LENGTH_LONG).show();
		}
	}

	// android获取一个用于打开PPT文件的intent
	private static Intent getPptFileIntent(Uri uri) {
		Intent intent = new Intent("android.intent.action.VIEW");
		intent.addCategory("android.intent.category.DEFAULT");
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setDataAndType(uri, "application/vnd.ms-powerpoint");
		return intent;
	}
}
