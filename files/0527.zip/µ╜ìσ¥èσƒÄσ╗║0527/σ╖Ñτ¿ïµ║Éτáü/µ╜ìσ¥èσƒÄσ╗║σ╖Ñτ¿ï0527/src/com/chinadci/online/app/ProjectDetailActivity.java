package com.chinadci.online.app;

import java.io.File;
import java.text.SimpleDateFormat;

import com.chinadci.online.app.fragment.ProjectDetailFragment;
import com.chinadci.online.app.utils.Configuration;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;

public class ProjectDetailActivity extends CommonBaseActivity {

	public static void open(Context context, String id) {
		Intent intent = new Intent(context, ProjectDetailActivity.class);
		intent.putExtra("id", id);
		context.startActivity(intent);
	}

	private String id;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.fragment_layout);
		id = getIntent().getStringExtra("id");
		switchFragment(ProjectDetailFragment.newInstance(id));
	}

	public void switchFragment(Fragment fragment) {
		getSupportFragmentManager().beginTransaction()
				.replace(R.id.fragment_content, fragment).commit();
	}

	private static final int REQUEST_VIDEO_CAPTURE = 1;
	
	private static final int REQUEST_IMAGE_CAPTURE = 2;

	@Override
	protected String getActionBarTitle() {
		// TODO Auto-generated method stub
		return "详情页";
	}
	private Uri fileUri;
	public void captureVideo() {
		Intent intent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
		fileUri = getOutputMediaFile("mp4");
		intent.putExtra(MediaStore.EXTRA_OUTPUT, fileUri);  
		intent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 1); 
		if (intent.resolveActivity(getPackageManager()) != null) {
			startActivityForResult(intent, REQUEST_VIDEO_CAPTURE);
		}
	}
	
	public void captureImage(){
		Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		fileUri = getOutputMediaFile("jpg");
		intent.putExtra(MediaStore.EXTRA_OUTPUT, fileUri);   
		if (intent.resolveActivity(getPackageManager()) != null) {
			startActivityForResult(intent, REQUEST_IMAGE_CAPTURE);
		}
	}
	
	private static Uri getOutputMediaFile(String extend){
		java.util.Date date= new java.util.Date();
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss")
                             .format(date.getTime());
        return Uri.fromFile(new File(Configuration.FILE_UPLOAD_CACHE,timeStamp+"."+extend));
	}
	

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, intent);
		if(resultCode == RESULT_OK){
			switch (requestCode) {
			case REQUEST_VIDEO_CAPTURE:
			case REQUEST_IMAGE_CAPTURE:
				UploadListActivity.open(this, id);
				
				break;
			
			}
		}
		

	}

}
