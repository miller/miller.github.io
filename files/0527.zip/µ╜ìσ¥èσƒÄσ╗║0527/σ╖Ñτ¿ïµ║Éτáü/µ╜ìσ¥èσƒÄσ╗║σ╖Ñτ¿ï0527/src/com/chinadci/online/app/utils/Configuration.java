package com.chinadci.online.app.utils;

import java.io.File;

import android.os.Environment;

public class Configuration {

	public static final File FOLDER = new File(Environment.getExternalStorageDirectory(),"/chinadci_cache/gg_geoFile");
	
	public static final File FILE_LOCAL = new File(Environment.getExternalStorageDirectory(),"chinadci");
	
	public static final File FILE_CACHE = new File(Environment.getExternalStorageDirectory(),"/chinadci_cache/file_cache");
	public static final File FILE_UPLOAD_CACHE = new File(Environment.getExternalStorageDirectory(),"/chinadci_cache/upload_cache");
	
	static{
		if(!FOLDER.exists()){
			FOLDER.mkdirs();
		}
		if(!FILE_LOCAL.exists()){
			FILE_LOCAL.mkdirs();
		}
		if(!FILE_CACHE.exists()){
			FILE_CACHE.mkdirs();
		}
		if(!FILE_UPLOAD_CACHE.exists()){
			FILE_UPLOAD_CACHE.mkdirs();
		}
	}
	
}
