package com.chinadci.online.app.fragment;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.chinadci.online.app.R;
import com.chinadci.online.app.adapter.TextListAdapter;
import com.chinadci.online.app.adapter.TextListAdapter.TextModel;
import com.chinadci.online.app.database.DataBaseHelper;
import com.chinadci.online.app.network.DataTableRequest;
import com.chinadci.online.app.network.Request;
import com.chinadci.online.app.network.DataTableRequest.Params;
import com.chinadci.online.app.network.DataTableRequest.Result;
import com.chinadci.online.app.network.RequestAsync;
import com.chinadci.online.app.network.RequestAsync.Async;
import com.chinadci.online.app.network.model.XMZXJZ;
import com.chinadci.online.app.utils.WigetUtils;
import com.chinadci.online.app.utils.WigetUtils.OnItemClickListener;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

public class XMZXJZFragment extends Fragment implements OnItemClickListener,OnPageChangeListener,OnClickListener{


	
	public static XMZXJZFragment newInstance(String id){
		XMZXJZFragment fragment = new XMZXJZFragment();
		fragment.id = id;
		return fragment;
	}
	
	private String id;
	
	
	
	
	
	private ViewPager viewPager;
	
	private DataBaseHelper helper;
	
	private View lastView;
	
	private ViewGroup group; 
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		return inflater.inflate(R.layout.zmzxjz_layout, null);
	}
	
	private Fragment[] fragments;
	
	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onViewCreated(view, savedInstanceState);
		helper = new DataBaseHelper(getActivity());
		view.findViewById(R.id.add_jinzhan).setOnClickListener(this);
		view.findViewById(R.id.add_wenti).setOnClickListener(this);
		fragments = new Fragment[]{
				XMZXJZjinzhanFragment.newInstance(id, "1"),
				 XMZXJZjinzhanFragment.newInstance(id, "2")
				
		};
		viewPager = (ViewPager) view.findViewById(R.id.pager);
		viewPager.setOnPageChangeListener(this);
		
		
		group = (ViewGroup) view.findViewById(R.id.tata);
		WigetUtils.onChildViewClick(group, this);
		
		viewPager.setAdapter(new MyAdapter());
		group.getChildAt(0).performClick();
	}
	
	
	private class MyAdapter extends FragmentStatePagerAdapter{
		
		
		
		public MyAdapter() {
			super(getChildFragmentManager());
			// TODO Auto-generated constructor stub
		}

		@Override
		public Fragment getItem(int arg0) {
			
			return fragments[arg0];
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return fragments.length;
		}
		
	}

	@Override
	public void onItemClick(ViewGroup group, View view, int position, long id) {
		if(lastView != null){
			lastView.setSelected(false);
		}
		view.setSelected(true);
		
		lastView = view;
		viewPager.setCurrentItem(position);
		
	}

	@Override
	public void onPageScrollStateChanged(int arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onPageScrolled(int arg0, float arg1, int arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onPageSelected(int arg0) {
		group.getChildAt(arg0).performClick();
		
	}
	
	private void add(String title,final String type){
		final EditText input = new EditText(getActivity());
		new AlertDialog.Builder(getActivity())
	    .setTitle(title)
	    .setView(input)
	    .setPositiveButton("提交", new DialogInterface.OnClickListener() {
	        public void onClick(DialogInterface dialog, int whichButton) {
	        	final String str = input.getText().toString(); 
	        	
	        	
	        	final ProgressDialog loading = ProgressDialog.show(getActivity(), "提示", "正在提交...",true);
	        	
	        	new AsyncTask<Void, Void, Result>() {

					@Override
					protected Result doInBackground(Void... d) {
						Params params = new Params("xmzxjz", new String[]{id,type,str}, new String[]{"xmbh","jllx","jlnr"});
			        	
			        	final DataTableRequest dataTableRequest = new DataTableRequest(params);
			        	dataTableRequest.request();
						return dataTableRequest.getResult();
					}
					
					protected void onPostExecute(Result result) {
						if(result.isSuccess()){
							XMZXJZ xmzxjz = new XMZXJZ();
							xmzxjz.PK = result.getReturnValue();
							xmzxjz.JLLX = type;
							xmzxjz.XMBH = id;
							xmzxjz.JLNR = str;
							try {
								helper.getXMZXJZDao().create(xmzxjz);
							} catch (SQLException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							Toast.makeText(getActivity(), "操作成功", Toast.LENGTH_SHORT).show();
							for(Fragment fragment:fragments){
				        		fragment.onResume();
				        	}
						}else{
							Toast.makeText(getActivity(), "操作失败", Toast.LENGTH_SHORT).show();
						}
						loading.dismiss();
					};
	        		
	        		
	        		
				}.execute();
	        
	        }
	    }).setNegativeButton("取消", new DialogInterface.OnClickListener() {
	        public void onClick(DialogInterface dialog, int whichButton) {
	        	
	            dialog.dismiss();
	        }
	    }).show();
	}

	@Override
	public void onClick(View v) {
		
		switch (v.getId()) {
		case R.id.add_jinzhan:
			add("添加进展","1");
			break;
		case R.id.add_wenti:
			add("添加问题","2");
			break;
		default:
			break;
		}
		
	}
	
}
