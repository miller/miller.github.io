package com.chinadci.online.app.network.model;


import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable(tableName = "PointRecord")
public class PointRecord {

	//[PRJTITLE, PRJOTHER01, PRJTYPE, PRJSTART03, PRJENDTIME, PRJINVES05, CONSTRUN06, CONSTRUC07, CONSTRUC08, RESPONSI09, COORDINA10, ASSOCIAT11, FIRSTRES12, TERRITOR13, PRJLEVEL, PRJAPPRO15, PLANNING16, LANDUSEA17, ENVIRONM18, FLOODPRO19, DEMOLITI20, PRJCURCI21, BIDDINGT22, WORKSTAR23, WORKENDT24, PAGEURL, ROWINDEX, REMARK, DELETEDS28, UPDATETIME, UID, RESPONSI31, EMAIL, PUBLICPH33, FAXPHONE, PJRCURIN35, PRJYEAR, PRJADDRESS, PRJPLAN, PRJCLEAR]
	
	@DatabaseField(id = true)
	private String  UID;
	
	@DatabaseField
	private int x;
	
	@DatabaseField
	private int y;
	
	private String name;
	
	public PointRecord() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	public PointRecord(String uID, int x, int y, String name) {
		super();
		UID = uID;
		this.x = x;
		this.y = y;
		this.name = name;
	}



	public PointRecord(String uID, int x, int y) {
		UID = uID;
		this.x = x;
		this.y = y;
	}


	public String getName() {
		return name;
	}

	public String getUID() {
		return UID;
	}
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	}
	
}
