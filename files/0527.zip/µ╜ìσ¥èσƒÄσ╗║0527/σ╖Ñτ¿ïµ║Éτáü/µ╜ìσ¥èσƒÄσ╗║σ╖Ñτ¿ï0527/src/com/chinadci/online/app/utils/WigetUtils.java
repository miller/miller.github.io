package com.chinadci.online.app.utils;

import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.ListView;

public class WigetUtils {

	public static void setListViewBasedOnChildren(ListView listView) {
		ListAdapter listAdapter = listView.getAdapter();
		if (listAdapter == null) {
			// pre-condition
			return;
		}
		int totalHeight = 0;
		int maxWidth = 0;
		for (int i = 0; i < listAdapter.getCount(); i++) {
			View listItem = listAdapter.getView(i, null, listView);
			listItem.measure(0, 0);
			totalHeight += listItem.getMeasuredHeight();
			int width = listItem.getMeasuredWidth();
			if (width > maxWidth)
				maxWidth = width;
		}

		ViewGroup.LayoutParams params = listView.getLayoutParams();
		params.height = totalHeight
				+ (listView.getDividerHeight() * (listAdapter.getCount() - 1));
		params.width = maxWidth;
		listView.setLayoutParams(params);
	}

	public static interface OnItemClickListener {
		public void onItemClick(ViewGroup group, View view, int position,
				long id);
	}

	public static void onChildViewClick(final ViewGroup viewGroup,
			final OnItemClickListener itemClickListener) {
		for (int i = 0; i < viewGroup.getChildCount(); i++) {
			final int k = i;
			viewGroup.getChildAt(i).setOnClickListener(new OnClickListener() {

				public void onClick(View v) {
					itemClickListener.onItemClick(viewGroup, v, k, v.getId());

				}
			});
		}
	}

	public static void switchVisible(ViewGroup viewGroup, int id) {
		for (int i = 0; i < viewGroup.getChildCount(); i++) {
			View view = viewGroup.getChildAt(i);
			if (view.getId() == id) {
				view.setVisibility(View.VISIBLE);
			} else {
				view.setVisibility(View.GONE);
			}
		}
	}

	public static void switchVisible(ViewGroup viewGroup, View _view) {
		for (int i = 0; i < viewGroup.getChildCount(); i++) {
			View view = viewGroup.getChildAt(i);
			if (_view == view) {
				view.setVisibility(View.VISIBLE);
			} else {
				view.setVisibility(View.GONE);
			}
		}
	}

	public static void setSelected(ViewGroup viewGroup, boolean selected) {
		for (int i = 0; i < viewGroup.getChildCount(); i++) {
			viewGroup.getChildAt(i).setSelected(selected);
		}
	}

}
