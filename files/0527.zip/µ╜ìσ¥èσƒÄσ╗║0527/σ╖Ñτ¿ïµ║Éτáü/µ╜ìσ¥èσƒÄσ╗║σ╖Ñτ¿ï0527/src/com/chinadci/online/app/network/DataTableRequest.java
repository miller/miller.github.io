package com.chinadci.online.app.network;

import java.util.List;

import org.apache.http.NameValuePair;

import com.google.gson.Gson;

public class DataTableRequest extends Request2{

	
	
	public static class Params{
		protected String tableName;
		protected String[] records;
		protected String[] fields;
		public Params(String tableName, String[] records, String[] fields) {
			super();
			this.tableName = tableName;
			this.records = records;
			this.fields = fields;
		}
		
	}
	
	public static class Result{
		private boolean success;
		private String returnValue;
		public Result(boolean success, String returnValue) {
			super();
			this.success = success;
			this.returnValue = returnValue;
		}
		public String getReturnValue() {
			return returnValue;
		}
		public boolean isSuccess() {
			return success;
		}
		
	}
	
	private String str;
	
	private Result result;
	
	public DataTableRequest(Params params) {
		str = new Gson().toJson(params);
	}
	
	@Override
	public void onSuccess(String data) {
		result = new Gson().fromJson(data, Result.class);
		
	}
	
	public Result getResult() {
		return result;
	}

	@Override
	public void onError(int code, String msg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onResultError(int code, String msg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onServerError(int code, String msg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getURL() {
		// TODO Auto-generated method stub
		return HOST+"api/DataTable";
	}
	
	@Override
	protected String fillStringParams() {
		// TODO Auto-generated method stub
		return str;
	}

	@Override
	public List<NameValuePair> fillParams() {
		// TODO Auto-generated method stub
		return null;
	}

}
