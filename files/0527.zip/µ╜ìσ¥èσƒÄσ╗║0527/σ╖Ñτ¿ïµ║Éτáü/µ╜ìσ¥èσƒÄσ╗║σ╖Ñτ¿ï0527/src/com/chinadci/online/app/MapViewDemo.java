package com.chinadci.online.app;

import java.sql.SQLException;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.TextView;

import com.chinadci.online.app.database.DataBaseHelper;
import com.chinadci.online.app.network.model.PointRecord;
import com.chinadci.online.app.network.model.ZDXM;
import com.chinadci.online.app.widget.MyMapView;
import com.tianditu.android.maps.GeoPoint;
import com.tianditu.android.maps.MapActivity;
import com.tianditu.android.maps.MapView;

public class MapViewDemo extends MapActivity implements OnClickListener {

	public static void open(Context context, String id) {
		Intent intent = new Intent(context, MapViewDemo.class);
		intent.putExtra("id", id);
		context.startActivity(intent);

	}

	private MyMapView mMapView;

	private View MenuBar;

	private View switchBtn;

	private TextView switchText;

	private ViewGroup container;

	private String id;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		id = getIntent().getStringExtra("id");
		setContentView(R.layout.map_layout);
		findViewById(R.id.frame_back).setOnClickListener(this);
		container = ((ViewGroup) findViewById(R.id.map_container));
		mMapView = MyMapView.getInstance(this);
		container.addView(mMapView);
		MenuBar = findViewById(R.id.menubar);
		switchBtn = findViewById(R.id.switchBtn);
		switchBtn.setOnClickListener(this);
		switchText = (TextView) findViewById(R.id.switchText);
		findViewById(R.id.tuli).setOnClickListener(this);

		try {
			init();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void init() throws SQLException {
		DataBaseHelper helper = new DataBaseHelper(this);

		PointRecord pointRecord = helper.getPointRecordDao().queryForId(id);
		ZDXM zdxm = helper.getZDXMDao().queryForId(id);
		if (pointRecord != null) {
			GeoPoint pt = new GeoPoint(pointRecord.getX(), pointRecord.getY());
			mMapView.getController().setCenter(pt);
			mMapView.popup(this, pointRecord.getUID(), zdxm.XMMC, pt);
		}
		
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		container.removeAllViews();
	}

	@Override
	protected boolean isRouteDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();

	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.tuli:
			if (MenuBar.getVisibility() == View.VISIBLE) {
				MenuBar.setVisibility(View.GONE);
			} else {
				MenuBar.setVisibility(View.VISIBLE);
			}
			break;
		case R.id.switchBtn:
			v.setSelected(!v.isSelected());
			mMapView.setMapType(v.isSelected() ? MapView.TMapType.MAP_TYPE_IMG
					: MapView.TMapType.MAP_TYPE_VEC);
			mMapView.requestLayout();
			mMapView.invalidate();
			if (v.isSelected()) {
				switchText.setText("天地图");
			} else {
				switchText.setText("影像图");
			}
			break;
		case R.id.frame_back:
			finish();
			break;
		default:
			break;
		}

	}

}
