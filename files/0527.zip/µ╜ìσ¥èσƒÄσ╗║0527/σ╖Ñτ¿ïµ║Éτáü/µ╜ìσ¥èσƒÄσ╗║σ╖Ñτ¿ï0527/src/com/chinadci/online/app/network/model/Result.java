package com.chinadci.online.app.network.model;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.reflect.FieldUtils;

public class Result {

	private String[] cols;
	
	private String[][] rows;
	
	public static List<Object> convert(Class<?> cls,Result result) throws Exception{
		List<Object> list = new ArrayList<Object>();
		
		for(String[] strs : result.rows){
			Object object = cls.getConstructor().newInstance();
			for(int i = 0;i<result.cols.length;i++){
				String colname = result.cols[i];
				String value = StringUtils.trim(strs[i]);
				Field field = FieldUtils.getField(cls, colname);
				
				if(field != null){
					if(field.getType() == Integer.class){
						field.set(object, Integer.parseInt(value));
					}else{
						field.set(object, value);
					}
					
					
				}
				
			}
			list.add(object);
			
		}
		return list;
	}
	
}
