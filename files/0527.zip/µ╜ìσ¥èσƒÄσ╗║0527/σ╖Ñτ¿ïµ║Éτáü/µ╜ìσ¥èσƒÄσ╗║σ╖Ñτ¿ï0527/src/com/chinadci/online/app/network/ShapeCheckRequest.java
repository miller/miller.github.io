package com.chinadci.online.app.network;

import java.util.List;

import org.apache.http.NameValuePair;

import com.chinadci.online.app.network.model.Preferences;
import com.chinadci.online.app.network.model.Preferences.Profile;

import android.content.Context;

public class ShapeCheckRequest extends Request{

	public static class Params{
		protected int type;
		protected String updatetime;
		
		private Profile profile;
		public Params(Context context, int type) {
			super();
			this.type = type;
			this.profile = new Preferences.Profile(context);
			if(type == 0){
				
				updatetime = profile.getPointLastUpdate();
			}else if(type ==2){
				updatetime = profile.getShapeLastUpdate();
			}
		}
		private void setTime(String time){
			if(type == 0){
				profile.setPointLastUpdate(time);
			}else if(type==2){
				profile.setShapeLastUpdate(time);
			}
		}
		
	}
	

	
	private Params params;
	
	private boolean hasNew;
	
	public ShapeCheckRequest(Params params) {
		super();
		this.params = params;
	}

	@Override
	public void onSuccess(String data) {
		
		if(data != null && data.indexOf('-') != -1){
			params.setTime(data);
			hasNew = true;
		}else{
			hasNew = false;
		}
	}
	
	public boolean isHasNew() {
		return hasNew;
	}

	@Override
	public void onError(int code, String msg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onResultError(int code, String msg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onServerError(int code, String msg) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	protected String getMethod() {
		// TODO Auto-generated method stub
		return "GET";
	}

	@Override
	public String getURL() {
		// TODO Auto-generated method stub
		return HOST+"api/ShapeUpdateTime";
	}

	@Override
	public List<NameValuePair> fillParams() {
		// TODO Auto-generated method stub
		return build(params);
	}

}
