package com.chinadci.online.app.fragment;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.chinadci.online.app.adapter.GalleryListAdapter;
import com.chinadci.online.app.adapter.TextListAdapter;
import com.chinadci.online.app.adapter.GalleryListAdapter.GalleryModel;
import com.chinadci.online.app.adapter.TextListAdapter.TextModel;
import com.chinadci.online.app.database.DataBaseHelper;
import com.chinadci.online.app.network.model.XMDSJ;
import com.chinadci.online.app.utils.DisplayUtils;
import com.chinadci.online.app.utils.ExtensionUtils;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.ListView;

public class XMDSJVideoFragment extends Fragment{

	public static XMDSJVideoFragment newInstance(String id){
		XMDSJVideoFragment fragment = new XMDSJVideoFragment();
		fragment.id = id;
		return fragment;
	}
	
	private GridView listView;
	
	private DataBaseHelper helper;
	
	private String id;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		listView = new GridView(getActivity());
		listView.setNumColumns(3);
		int space = DisplayUtils.Dp2Px(getActivity(), 3);
		listView.setHorizontalSpacing(space);
		listView.setVerticalSpacing(space);
		return listView;
	}
	
	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onViewCreated(view, savedInstanceState);
		helper = new DataBaseHelper(getActivity());
		 
		
		try {
			load();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	private void load() throws SQLException{
		//for id
//		String query = "select trim(t2.ZLDZ),t2.ZLLX as address from dsjsp t1 join zlk t2 on (t1.ZLBH = t2.PK) where address != ''";
		String query = "select trim(t2.ZLDZ),t2.ZLLX as address,t3.XMBH as xmbh from dsjsp t1 join zlk t2,xmdsj t3 on (t1.ZLBH = t2.PK and t1.SJBH=t3.PK) where address != '' and xmbh = '"+id+"'";
		List<String[]> result = helper.getXMDSJDao().queryRaw(query).getResults();
		List<GalleryModel> list = new ArrayList<GalleryModel>();
		for(String[] row : result){
			
			if(ExtensionUtils.isVideoExtension(row[1])){
				GalleryModel model = new GalleryModel(row[0], "");
				list.add(model);
			}
		}
		GalleryListAdapter adapter = new GalleryListAdapter(getActivity(), list, false);
		listView.setAdapter(adapter);
	}
	
}
