package com.chinadci.online.app.fragment;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.chinadci.online.app.adapter.ProjectListAdapter;
import com.chinadci.online.app.adapter.ProjectListAdapter.Project;
import com.chinadci.online.app.database.DataBaseHelper;
import com.chinadci.online.app.network.Update;
import com.chinadci.online.app.network.model.ZDXM;
import com.chinadci.online.app.widget.BaseListView;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener;
import com.j256.ormlite.stmt.Where;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ListView;

public class ProjectAllCurrentFragment extends Fragment implements TextWatcher{

	public enum Status1{
		CURRENT,HISTORY
	}
	
	public static ProjectAllCurrentFragment newInstance(EditText editText,Status1 status){
		ProjectAllCurrentFragment allCurrentFragment = new ProjectAllCurrentFragment();
		allCurrentFragment.status  = status;
		allCurrentFragment.editText = editText;
		return allCurrentFragment;
	}
	
	private BaseListView listView;
	
	private ProjectListAdapter adapter;
	
	private EditText editText;
	
	private Status1 status;
	
	private List<Project> list = new ArrayList<ProjectListAdapter.Project>();
	
	private DataBaseHelper helper ;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		listView = new BaseListView(getActivity());
		return listView;
	}
	
	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onViewCreated(view, savedInstanceState);
		editText.addTextChangedListener(this);
		helper = new DataBaseHelper(getActivity());
		
		
		try {
			list = ZDXM.toProjectList(helper.getZDXMDao().queryForAll());
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		adapter = new ProjectListAdapter(getActivity(), list);
		listView.setAdapter(adapter);
		listView.setOnRefreshListener(new OnRefreshListener<ListView>() {

			
			public void onRefresh(PullToRefreshBase<ListView> refreshView) {
				
				new Thread(new Runnable() {
					
					@Override
					public void run() {
						Update.update(getActivity());
						load();
						
					}
				}).start();
				
			}
		});
		
		afterTextChanged(editText.getEditableText());
	}
	
	private void load(){
		new AsyncTask<Void, Void, List<Project>>() {

			@Override
			protected List<Project> doInBackground(Void... params) {
				
				
				
				List<Project> list = new ArrayList<ProjectListAdapter.Project>();
				
				try {
					Where<ZDXM,String>  where = helper.getZDXMDao().queryBuilder().orderBy("PXH", true).where();
					if(status == Status1.CURRENT){
						where.notIn("JSJD", "完工");
					}else{
						where.eq("JSJD", "完工");
					}
					list = ZDXM.toProjectList(where.query());
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return list;
			}
			
			@Override
			protected void onPostExecute(List<Project> result) {
				list.clear();
				list.addAll(result);
				adapter.notifyDataSetChanged();
				listView.onRefreshComplete();
				
			}
			
		}.execute();
	}

	@Override
	public void afterTextChanged(Editable s) {
		String str = s.toString();
		list.clear();
		try {
			Where<ZDXM,String>  where = helper.getZDXMDao().queryBuilder().orderBy("PXH", true).orderBy("PK", false).where();
			if(status == Status1.CURRENT){
				where.notIn("JSJD", "完工").and();
			}else{
				where.eq("JSJD", "完工").and();
			}
			list.addAll(ZDXM.toProjectList(where.like("XMMC", "%"+str+"%").query()));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		adapter.notifyDataSetChanged();
		
	}

	@Override
	public void beforeTextChanged(CharSequence s, int start, int count,
			int after) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onTextChanged(CharSequence s, int start, int before, int count) {
		// TODO Auto-generated method stub
		
	}
	
}
