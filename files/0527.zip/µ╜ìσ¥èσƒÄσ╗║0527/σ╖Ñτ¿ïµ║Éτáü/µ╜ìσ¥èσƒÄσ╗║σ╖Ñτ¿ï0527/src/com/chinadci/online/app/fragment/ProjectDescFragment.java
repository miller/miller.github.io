package com.chinadci.online.app.fragment;

import java.sql.SQLException;

import com.chinadci.online.app.R;
import com.chinadci.online.app.database.DataBaseHelper;
import com.chinadci.online.app.network.model.ZDXM;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class ProjectDescFragment extends Fragment {

	public static ProjectDescFragment newInstance(String id){
		ProjectDescFragment descFragment = new ProjectDescFragment();
		descFragment.id = id;
		return descFragment;
	}
	
	private TextView mingchengView;

	private TextView danweiView;

	private TextView zerenrenView;

	private TextView touziView;

	private TextView gaikuangView;

	private TextView anpaiView;

	private TextView jinduView;

	private TextView riqiView;

	private TextView leibieView;

	private TextView zongtouziView;
	
	private String id;
	
	private DataBaseHelper helper;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		return inflater.inflate(R.layout.project_desc_layout, null);
	}

	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onViewCreated(view, savedInstanceState);
		helper = new DataBaseHelper(getActivity());
		mingchengView = (TextView) view.findViewById(R.id.mingcheng);
		danweiView = (TextView) view.findViewById(R.id.danwei);
		zerenrenView = (TextView) view.findViewById(R.id.zerenren);
		touziView = (TextView) view.findViewById(R.id.touzi);
		gaikuangView = (TextView) view.findViewById(R.id.gaikuang);
		anpaiView = (TextView) view.findViewById(R.id.anpai);
		jinduView = (TextView) view.findViewById(R.id.jindu);
		riqiView = (TextView) view.findViewById(R.id.riqi);
		leibieView = (TextView) view.findViewById(R.id.leibie);
		zongtouziView = (TextView) view.findViewById(R.id.zongtouzi);

	}
	
	@Override
	public void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		
		try {
			ZDXM zdxm = helper.getZDXMDao().queryForId(id);
			mingchengView.setText(getString(R.string.p_mingcheng, zdxm.XMMC));
			danweiView.setText(getString(R.string.p_danwei, zdxm.QTZRDW));
			zerenrenView.setText(getString(R.string.p_zerenren, zdxm.ZRR));
			touziView.setText(getString(R.string.p_touzi, zdxm.NDTZ));
			gaikuangView.setText(getString(R.string.p_gaikuang, zdxm.JSNR));
			anpaiView.setText(getString(R.string.p_anpai, zdxm.JHAP));
			jinduView.setText(getString(R.string.p_jindu, zdxm.YDQK));
			riqiView.setText(getString(R.string.p_riqi, zdxm.KGSJ));
			leibieView.setText(getString(R.string.p_leibie, zdxm.XMLB));
			zongtouziView.setText(getString(R.string.p_zongtouzi, zdxm.ZTZ));
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
