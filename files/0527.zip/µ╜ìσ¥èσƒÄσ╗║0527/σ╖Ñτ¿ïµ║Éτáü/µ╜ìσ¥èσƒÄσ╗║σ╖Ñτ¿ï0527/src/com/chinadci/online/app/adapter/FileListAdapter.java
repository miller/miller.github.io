package com.chinadci.online.app.adapter;

import java.io.File;
import java.util.HashMap;
import java.util.List;

import com.chinadci.online.app.R;
import com.chinadci.online.app.utils.IntentUtils;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class FileListAdapter extends BaseAdapter{

	public enum FileType{
		DOC(R.drawable.fy_doc),EXCEL(R.drawable.fy_excel),
		PIC(R.drawable.fy_image),PDF(R.drawable.fy_pdf),
		VIDEO(R.drawable.fy_video),AUDIO(R.drawable.fy_audio),TEXT(R.drawable.fy_txt);
		
		private int drawable;
		FileType(int drawable){
			this.drawable = drawable;
		}
		public int getDrawable() {
			return drawable;
		}
		public void open(Context context,String file){
			File f = new File(file);
			Uri uri = Uri.fromFile(f);
			switch (this) {
			case DOC:
				IntentUtils.startWordActivity(context, uri);
				break;
			case EXCEL:
				IntentUtils.startExcelActivity(context, uri);
				break;
			case PIC:
				IntentUtils.startImageActivity(context,f.getName(), uri);
				break;
			case PDF:
				IntentUtils.startPdfActivity(context, uri);
				break;
			case VIDEO:
				IntentUtils.startVideoActivity(context, uri);
				break;
			case AUDIO:
				IntentUtils.startAudioActivity(context, file);
				break;
			case TEXT:
				IntentUtils.startTextActivity(context, file);
				break;
			default:
				break;
			}
			
		}
		
		
		
	}
	
	public static class FileModel{
		
		//jpg","jpeg","doc","docx","xls","xlsx","pdf","mp4","mp3","gif","png"
		
		public static FileType getFileType(String str){
			str = str.toLowerCase();
			FileType fileType = new HashMap<String, FileType>(){{
				put("doc", FileType.DOC);
				put("docx", FileType.DOC);
				put("xls", FileType.EXCEL);
				put("xlsx", FileType.EXCEL);
				put("jpg", FileType.PIC);
				put("jpeg", FileType.PIC);
				put("gif", FileType.PIC);
				put("png", FileType.PIC);
				put("pdf", FileType.PDF);
				put("mp4", FileType.VIDEO);
				put("mp3", FileType.AUDIO);
				put("txt", FileType.TEXT);
			}}.get(str);
			return fileType;
		}
		
		private String url;
		private String name;
		private FileType type;
		public FileModel(String url, String name, FileType type) {
			super();
			this.url = url;
			this.name = name;
			this.type = type;
		}
		public String getUrl() {
			return url;
		}
		public String getName() {
			return name;
		}
		
		public FileType getType() {
			return type;
		}
		
		
	}
	
	private Context context;
	
	private List<FileModel> list;

	
	
	public FileListAdapter(Context context, List<FileModel> list) {
		super();
		this.context = context;
		this.list = list;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder = null;
		FileModel fileModel = list.get(position);
		if(convertView == null){
			convertView = LayoutInflater.from(context).inflate(
					R.layout.file_item, null);
			holder = new ViewHolder(convertView);
			convertView.setTag(holder);
		}else{
			holder = (ViewHolder) convertView.getTag();
		}
		
		holder.typeView.setImageResource(fileModel.type.getDrawable());
		
		holder.titleView.setText(fileModel.name);
		
		return convertView;
	}
	
	private class ViewHolder{
		private ImageView typeView;
		private TextView titleView;
		public ViewHolder(View view) {
			typeView = (ImageView) view.findViewById(R.id.type);
			titleView = (TextView) view.findViewById(R.id.title);
		}
	}
	
}
