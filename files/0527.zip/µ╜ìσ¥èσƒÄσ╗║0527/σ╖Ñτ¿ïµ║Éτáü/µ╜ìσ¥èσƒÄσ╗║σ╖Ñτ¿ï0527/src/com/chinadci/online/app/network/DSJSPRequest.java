package com.chinadci.online.app.network;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;

import com.chinadci.online.app.network.model.DSJSP;
import com.chinadci.online.app.network.model.Result;
import com.chinadci.online.app.network.model.XMFJZL;
import com.chinadci.online.app.network.model.ZDXM;
import com.google.gson.Gson;

public class DSJSPRequest extends Request{

	public static class Params{
		protected String tablename = "DSJSP";
		protected String lastupdate;
		protected int count = 30;
		public Params(String lastupdate) {
			super();
			this.lastupdate = lastupdate;
		}
		
	}
	
	private Params params;
	
	
	
	public DSJSPRequest(Params params) {
		super();
		this.params = params;
	}
	
	private List<DSJSP> list = new ArrayList<DSJSP>();
	
	@Override
	public void onSuccess(String data) {
		Result result = new Gson().fromJson(data, Result.class);
		try {
			list = (List<DSJSP>)((List<?>)Result.convert(DSJSP.class, result));
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public List<DSJSP> getList() {
		return list;
	}

	@Override
	public void onError(int code, String msg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onResultError(int code, String msg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onServerError(int code, String msg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getURL() {
		// TODO Auto-generated method stub
		return "http://119.191.58.252:809/WFZDXM/api/datatable";
	}
	

	@Override
	public List<NameValuePair> fillParams() {
		// TODO Auto-generated method stub
		return build(params);
	}
	
	@Override
	protected String getMethod() {
		// TODO Auto-generated method stub
		return "GET";
	}

}
