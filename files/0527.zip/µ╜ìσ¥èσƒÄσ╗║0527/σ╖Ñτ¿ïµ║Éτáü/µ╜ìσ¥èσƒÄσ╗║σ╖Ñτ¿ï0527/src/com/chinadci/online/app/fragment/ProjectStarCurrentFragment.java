package com.chinadci.online.app.fragment;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import android.content.Context;

import com.chinadci.online.app.fragment.CommonItemFragment.Status1;
import com.chinadci.online.app.network.model.ZDXM;
import com.j256.ormlite.stmt.Where;

public class ProjectStarCurrentFragment extends CommonItem1Fragment {

	@Override
	public List<ZDXM> onChange(String text) {
		List<ZDXM> list = new ArrayList<ZDXM>();
		try {
			Where<ZDXM, String> where = helper.getZDXMDao().queryBuilder()
					.where().eq("stared",true);
			where.and();
			buildStatus(where,Status1.CURRENT);
			list = where.query();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	


}
