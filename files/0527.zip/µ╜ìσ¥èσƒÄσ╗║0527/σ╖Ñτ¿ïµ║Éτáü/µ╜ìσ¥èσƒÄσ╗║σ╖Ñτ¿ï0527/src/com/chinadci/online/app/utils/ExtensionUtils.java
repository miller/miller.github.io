package com.chinadci.online.app.utils;

import java.util.Arrays;

import android.content.Context;
import android.net.Uri;

public class ExtensionUtils {

	private static final String videoExtension[] = new String[]{
		"mov","mpg","avi","mp4","mpeg","wmv","flv","mkv","3gp","rmvb"
	};
	
	private static final String wordExtension[] = new String[]{
		"doc","docx"
	};
	
	private static final String excelExtension[] = new String[]{
		"xls","xlsx"
	};
	private static final String pptExtension[] = new String[]{
		"ppt","pptx"
	};
	private static final String imageExtension[] = new String[]{
		"jpg","jpeg","gif","png"
	};
	
	public static boolean isVideoExtension(String extend){
		
		return Arrays.asList(videoExtension).indexOf(extend.toLowerCase()) != -1;
	}
	
	public static boolean isWordExtension(String extend){
		
		return Arrays.asList(wordExtension).indexOf(extend.toLowerCase()) != -1;
	}
	
	public static boolean isExcelExtension(String extend){
		
		return Arrays.asList(excelExtension).indexOf(extend.toLowerCase()) != -1;
	}
	
	public static boolean isPPTExtension(String extend){
		
		return Arrays.asList(pptExtension).indexOf(extend.toLowerCase()) != -1;
	}
	
	public static boolean isImageExtension(String extend){
		
		return Arrays.asList(imageExtension).indexOf(extend.toLowerCase()) != -1;
	}
	
	public static void startActivity(Context context,Uri uri,String extend){
		if(isWordExtension(extend)){
			IntentUtils.startWordActivity(context, uri);
		}else if(isVideoExtension(extend)){
			IntentUtils.startVideoActivity(context, uri);
		}else if(isExcelExtension(extend)){
			IntentUtils.startExcelActivity(context, uri);
		}else if(isPPTExtension(extend)){
			IntentUtils.startPptActivity(context, uri);
		}else if(isImageExtension(extend)){
			IntentUtils.startImageActivity(context, uri.toString(), uri);
		}
	}
	
}
