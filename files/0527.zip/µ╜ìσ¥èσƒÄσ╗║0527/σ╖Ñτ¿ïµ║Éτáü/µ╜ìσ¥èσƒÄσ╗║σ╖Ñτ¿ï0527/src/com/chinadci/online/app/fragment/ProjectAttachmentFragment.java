package com.chinadci.online.app.fragment;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.chinadci.online.app.R;
import com.chinadci.online.app.adapter.ProjectAttachListAdapter;
import com.chinadci.online.app.adapter.ProjectAttachListAdapter.OnAttachClickListner;
import com.chinadci.online.app.adapter.ProjectAttachListAdapter.ProjectAttach;
import com.chinadci.online.app.adapter.ProjectAttachListAdapter.ProjectAttachGroup;
import com.chinadci.online.app.database.DataBaseHelper;
import com.chinadci.online.app.network.Request;
import com.chinadci.online.app.network.model.ZLK;
import com.chinadci.online.app.utils.ExtensionUtils;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

public class ProjectAttachmentFragment extends Fragment implements OnItemClickListener,OnAttachClickListner {

	public static ProjectAttachmentFragment newInstance(String pid) {
		ProjectAttachmentFragment attachmentFragment = new ProjectAttachmentFragment();
		attachmentFragment.pid = pid;
		return attachmentFragment;
	}

	private ListView listView;

	private DataBaseHelper helper;

	private String pid;

	private ProjectAttachListAdapter adapter;

	private List<ProjectAttachGroup> list = new ArrayList<ProjectAttachGroup>();

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		return inflater.inflate(R.layout.project_attach_layout, null);
	}

	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onViewCreated(view, savedInstanceState);
		helper = new DataBaseHelper(getActivity());
		listView = (ListView) view.findViewById(R.id.listview);
		listView.setOnItemClickListener(this);
		try {
			/*list = ProjectAttachGroup.toProjectAttachGroup(helper
					.getXMFJZLDao().queryForAll());*/
			list = ProjectAttachGroup.toProjectAttachGroup(helper
					.getXMFJZLDao().queryBuilder().where().eq("XMBH", pid)
					.query());
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		adapter = new ProjectAttachListAdapter(getActivity(), list, this);
		listView.setAdapter(adapter);

	}

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onClick(ProjectAttach attach) {
		try {
			ZLK zlk = helper.getZLKDao().queryForId(attach.id);
			if(zlk != null){
				String url = Request.STATIC +zlk.ZLDZ;
				ExtensionUtils.startActivity(getActivity(), Uri.parse(url), zlk.ZLLX);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}



}
