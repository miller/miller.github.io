package com.chinadci.online.app.fragment;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.chinadci.online.app.ProjectDetailActivity;
import com.chinadci.online.app.R;
import com.chinadci.online.app.UploadListActivity;
import com.chinadci.online.app.adapter.GalleryListAdapter;
import com.chinadci.online.app.adapter.GalleryListAdapter.GalleryModel;
import com.chinadci.online.app.database.DataBaseHelper;
import com.chinadci.online.app.network.Request;
import com.chinadci.online.app.network.Update;
import com.chinadci.online.app.network.model.XMXC;
import com.chinadci.online.app.utils.ExtensionUtils;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.webkit.MimeTypeMap;
import android.widget.GridView;

public class XMYXZLFragment extends Fragment implements OnClickListener{

	public static XMYXZLFragment newInstance(String id){
		XMYXZLFragment fragment = new XMYXZLFragment();
		fragment.id = id;
		return fragment;
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		return inflater.inflate(R.layout.xmyxzl_layout, null);
	}
	
	private GridView gridView;
	
	private GalleryListAdapter adapter;
	
	private DataBaseHelper helper;
	
	private String id;
	
	List<GalleryModel> list = new ArrayList<GalleryListAdapter.GalleryModel>();
	
	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onViewCreated(view, savedInstanceState);
		view.findViewById(R.id.upload_btn).setOnClickListener(this);
		view.findViewById(R.id.capture).setOnClickListener(this);
		gridView = (GridView) view.findViewById(R.id.gridview);
		adapter = new GalleryListAdapter(getActivity(), list,false);
		gridView.setAdapter(adapter);
		helper = new DataBaseHelper(getActivity());
		
	}
	
	private void load() throws SQLException{
		
//		String query ="select t1.ZLDZ,t1.ZLLX as zllx from zlk t1 join xmxc t2 on (t1.PK = t2.ZLBH) where zllx != '{null}'";
		String query ="select t1.ZLDZ,t2.XMBH as xmbh from zlk t1 join xmxc t2 on (t1.PK = t2.ZLBH) where xmbh = '"+id+"'";
		List<GalleryModel> models = new ArrayList<GalleryListAdapter.GalleryModel>();
		List<String[]> results = helper.getXMXCDao().queryRaw(query).getResults();
		for(String[] row : results){
			GalleryModel model;
			String zllx = MimeTypeMap.getFileExtensionFromUrl(row[0]);
			
			if(ExtensionUtils.isVideoExtension(zllx)){
				model = new GalleryModel(Request.STATIC+row[0],"");
			}else{
				model = new GalleryModel(Request.STATIC+row[0]);
			}
			models.add(model);
		}
		
		list.clear();
		list.addAll(models);
		adapter.notifyDataSetChanged();
		
	}
	
	@Override
	public void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		
		new AsyncTask() {

			@Override
			protected Object doInBackground(Object... params) {
				Update.XMXCUpdate(getActivity());
				Update.ZLKUpdate(getActivity());
				
				return null;
			}
			
			protected void onPostExecute(Object result) {
				try {
					load();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			};
			
		}.execute();
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.capture:
			
			showList();
			break;
		case R.id.upload_btn:
			UploadListActivity.open(getActivity(), id);
			break;
		default:
			break;
		}
		
	}
	
	private void showList(){
		 new AlertDialog.Builder(getActivity()).setTitle("选择")
		 .setItems (new String[]{
				 "拍照","录像"
		 }, new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				ProjectDetailActivity activity = ((ProjectDetailActivity)getActivity());
				switch (which) {
				case 0:
					activity.captureImage();
					break;
				case 1:
					activity.captureVideo();
				}
				
			}
		}).show();
	}
	
	
	
}
