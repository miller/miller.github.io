package com.chinadci.online.app.fragment;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.chinadci.online.app.R;
import com.chinadci.online.app.adapter.TextListAdapter;
import com.chinadci.online.app.adapter.TextListAdapter.TextModel;
import com.chinadci.online.app.database.DataBaseHelper;
import com.chinadci.online.app.network.model.XMZXJZ;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

public class XMZXJZjinzhanFragment extends Fragment{
	
	public static XMZXJZjinzhanFragment newInstance(String id,String type){
		XMZXJZjinzhanFragment fragment = new XMZXJZjinzhanFragment();
		fragment.id = id;
		fragment.type = type;
		return fragment;
	}
	
	private ListView listView1;
	private List<TextModel> list1;
	private TextListAdapter adapter1;
	private String id;
	
	private String type;
	
	private DataBaseHelper helper;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		helper = new DataBaseHelper(getActivity());
		listView1 = new ListView(getActivity());
		listView1.setBackgroundResource(R.drawable.bg_radius_gray_border);
		return listView1;
	}
	
	private static List<TextModel> toTextList(List<XMZXJZ> list){
		List<TextModel> res = new ArrayList<TextModel>();
		for(XMZXJZ row:list){
			res.add(new TextModel(row.PK, row.JLNR));
		}
		return res;
	}
	
	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onViewCreated(view, savedInstanceState);
		
	}
	
	@Override
	public void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		try {
			load();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	private void load() throws SQLException{
//		List<XMZXJZ> list = helper.getXMZXJZDao().queryForEq("JLLX", type);
		
		List<XMZXJZ> list = helper.getXMZXJZDao().queryForFieldValues(new HashMap<String, Object>(){{
			put("XMBH", id);
			put("JLLX", type);
		}});
		list1 = toTextList(list);
		
		adapter1 = new TextListAdapter(getActivity(), list1);
		
		listView1.setAdapter(adapter1);
		
	}

}
