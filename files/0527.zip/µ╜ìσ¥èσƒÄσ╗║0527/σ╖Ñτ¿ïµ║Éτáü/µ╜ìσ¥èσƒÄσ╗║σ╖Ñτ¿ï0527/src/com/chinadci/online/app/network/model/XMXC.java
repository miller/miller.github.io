package com.chinadci.online.app.network.model;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

//cols":["PK","XMBH","ZLBH","ZPM","PXH","ISDELETE","LASTUPDATE"],"
@DatabaseTable(tableName = "XMXC")
public class XMXC {

	@DatabaseField(id = true)
	public String PK;
	
	@DatabaseField
	public String XMBH;
	@DatabaseField
	public String ZLBH;
	@DatabaseField
	public String ZPM;
	@DatabaseField
	public String PXH;
	@DatabaseField
	public String ISDELETE;
	@DatabaseField
	public String LASTUPDATE;
}
