package com.chinadci.online.app;

import com.chinadci.online.app.fragment.AllProjectFragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.view.KeyEvent;

public class BaseActivity extends FragmentActivity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.fragment_layout);
		
		
	}
	
	public void switchFragment(String tag,Fragment fragment){
		getSupportFragmentManager().beginTransaction().replace(R.id.fragment_content, fragment) .commit();
	}
	
	
}
