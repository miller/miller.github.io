package com.chinadci.online.app.fragment;

import java.util.List;

import com.chinadci.online.app.fragment.CommonItemFragment.Status1;
import com.chinadci.online.app.network.model.ZDXM;

public interface ICommonItemFragment {

	public List<ZDXM> onChange(String text);
	
}
