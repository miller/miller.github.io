package com.chinadci.online.app.fragment;

import java.util.ArrayList;
import java.util.List;

import com.chinadci.online.app.R;
import com.chinadci.online.app.utils.WigetUtils;
import com.chinadci.online.app.utils.WigetUtils.OnItemClickListener;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class ProjectDetailFragment extends Fragment implements OnPageChangeListener,OnItemClickListener{

	public static ProjectDetailFragment newInstance(String id){
		ProjectDetailFragment detailFragment = new ProjectDetailFragment();
		detailFragment.id = id;
		return detailFragment;
	}
	
	private ViewPager viewPager;
	
	private ViewGroup group;
	
	private Fragment[] fragments ;
	
	private String id;
	
	private View lastView;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		return inflater.inflate(R.layout.project_main_layout, null);
	}
	

	
	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onViewCreated(view, savedInstanceState);
		
		viewPager = (ViewPager) view.findViewById(R.id.pager);
		viewPager.setOffscreenPageLimit(6);
		viewPager.setAdapter(new MyAdapter());
		viewPager.setOnPageChangeListener(this);
		group = (ViewGroup)view.findViewById(R.id.tabContainer);
		WigetUtils.onChildViewClick(group, this);
		group.getChildAt(0).performClick();
		
	}

	@Override
	public void onPageScrollStateChanged(int arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onPageScrolled(int arg0, float arg1, int arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onPageSelected(int arg0) {
		group.getChildAt(arg0).performClick();
		
	}

	@Override
	public void onItemClick(ViewGroup group, View view, int position, long id) {
		if(lastView != null){
			lastView.setSelected(false);
		}
		view.setSelected(true);
		
		lastView = view;
		
		viewPager.setCurrentItem(position);
		
	}
	
	private class MyAdapter extends FragmentStatePagerAdapter{

		 
		
		public MyAdapter() {
			super(getChildFragmentManager());
			// TODO Auto-generated constructor stub
		}

		@Override
		public Fragment getItem(int arg0) {
			//fragments =  new Fragment[]{ProjectDescFragment.newInstance(id),ProjectAttachmentFragment.newInstance(id),XMYXZLFragment.newInstance(id),XMDSJFragment.newInstance(id),XMDSJFragment.newInstance(id)};
			// TODO Auto-generated method stub
			Fragment fragment = null;
			switch (arg0) {
			case 0:
				fragment = ProjectDescFragment.newInstance(id);
				break;
			case 1:
				fragment = ProjectAttachmentFragment.newInstance(id);
				break;
			case 2:
				fragment = XMYXZLFragment.newInstance(id);
				break;
			case 3:
				fragment = XMDSJFragment.newInstance(id);
				break;
			case 4:
				fragment = XMZXJZFragment.newInstance(id);
				break;
		
			
			}
			
			
			return fragment;
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return 5;
		}
		

		
		
	}
	
	
}
