package com.chinadci.online.app.widget;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.Shader;
import android.graphics.Paint.Style;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.PathShape;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.chinadci.online.app.ProjectDetailActivity;
import com.chinadci.online.app.R;
import com.chinadci.online.app.database.DataBaseHelper;
import com.chinadci.online.app.network.model.PointRecord;
import com.chinadci.online.app.network.model.ShapeRecord;
import com.chinadci.online.app.network.model.ZDXM;
import com.j256.ormlite.dao.GenericRawResults;
import com.tianditu.android.maps.GeoPoint;
import com.tianditu.android.maps.ItemizedOverlay;
import com.tianditu.android.maps.MapController;
import com.tianditu.android.maps.MapView;
import com.tianditu.android.maps.Overlay;
import com.tianditu.android.maps.OverlayItem;
import com.tianditu.android.maps.Projection;

public class MyMapView extends MapView{

	public TextView mText = null;
	public View mPopView = null;
	
	private static MyMapView instance;
	
	public static MyMapView getInstance(Context context) {
		if(instance == null){
			instance = new MyMapView(context, "");
		}
		return instance;
	}
	
	public MyMapView(Context arg0, AttributeSet arg1, int arg2) {
		super(arg0, arg1, arg2);
		try {
			init();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public MyMapView(Context arg0, AttributeSet arg1) {
		super(arg0, arg1);
		try {
			init();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	

	public MyMapView(Context arg0, String arg1) {
		super(arg0, arg1);
		try {
			init();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void init() throws SQLException {
		this.setPlaceName(true);
		this.setLogoPos(MapView.LOGO_RIGHT_BOTTOM);
		this.setMapType(TMapType.MAP_TYPE_VEC);
		this.setBuiltInZoomControls(false);
		MapController mController = this.getController();
		mController.setZoom(10);
		getAllOverItem(getContext());
		for (MyOverlay myOverlay : getAllShapeOverlay(getContext())) {
			this.getOverlays().add(myOverlay);
		}

		for (OverItemT t : getAllOverItem(getContext())) {
			this.getOverlays().add(t);
		}
		mPopView = inflate( getContext(),R.layout.pop_up_view, null);
		mText = (TextView) mPopView.findViewById(R.id.name);
		addView(mPopView, new MapView.LayoutParams(
				ViewGroup.LayoutParams.WRAP_CONTENT,
				ViewGroup.LayoutParams.WRAP_CONTENT, null,
				MapView.LayoutParams.TOP_LEFT));
		mPopView.setVisibility(View.GONE);
	}

	@Override
	public boolean onTouchEvent(MotionEvent arg0) {
		boolean rev = false;
		try{
			rev = super.onTouchEvent(arg0);
		}catch(OutOfMemoryError e) {
			e.printStackTrace();
			System.gc();
		}catch(Exception e){
			
		}
		return rev;
	}
	
	public static final Map<String, Integer> TYPEMAP = new HashMap<String, Integer>(){{
		put("完工", R.drawable.poi_red);
		put("开工", R.drawable.poi_green);
		put("未开工", R.drawable.poi_blue);
		put("停工", R.drawable.poi_orange);
	}};
	public ArrayList<OverItemT> getAllOverItem( Context context) throws SQLException{
		return getOverItem("",context);
	}
	
	public void popup(final Context context, final String id,
			String title, GeoPoint pt) {
		if(mPopView != null){
			LayoutParams layoutParams = new MapView.LayoutParams(
					LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, pt,
					MapView.LayoutParams.CENTER);
			layoutParams.y = -30;
			this.updateViewLayout(this.mPopView,
					layoutParams);
			this.mPopView.setVisibility(View.VISIBLE);
			this.mText.setText(title);
			this.mPopView.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					ProjectDetailActivity.open(context, StringUtils.trim(id));

				}
			});
		}
		
	}
	
	public ArrayList<OverItemT> getOverItem(String where, Context context) throws SQLException{
		Map<String, List<PointRecord>> map = new HashMap<String, List<PointRecord>>();
		String query = "select zdxm.PK,zdxm.XMMC,shape.x,shape.y,zdxm.JSJD  from (select PK,XMMC,JSJD from ZDXM "+where+" ) zdxm  join (select UID,x,y from PointRecord) shape on (zdxm.PK=shape.UID)";
		DataBaseHelper baseHelper = new DataBaseHelper(context);
		GenericRawResults<String[]> results =baseHelper.getPointRecordDao().queryRaw(query);
		for(String[] row : results.getResults()){
			List<PointRecord> list = map.get(row[4]);
			if(list == null){
				list = new ArrayList<PointRecord>();
				map.put(row[4], list);
			}
			PointRecord record = new PointRecord(row[0],Integer.parseInt(row[2]),Integer.parseInt(row[3]), row[1]);
			list.add(record);
		} 
		
		ArrayList<OverItemT> overItemTs = new ArrayList<OverItemT>();
		
		for(String type : map.keySet()){
			Integer drawble =  TYPEMAP.get(type);
			if(drawble != null){
				List<PointRecord> records = map.get(type);
				overItemTs.add(new OverItemT(context, records, context.getResources().getDrawable(drawble)));
			}
		}
		
		return overItemTs;
	}
	
	private static class Bounds {
		private int x1;
		private int x2;
		private int y1;
		private int y2;

		public Bounds(int x1, int x2, int y1, int y2) {
			super();
			this.x1 = x1;
			this.x2 = x2;
			this.y1 = y1;
			this.y2 = y2;
		}

		public boolean reject(int x, int y) {
			if (x > x1 && x < x2 && y > y1 && y < y2) {
				return true;
			}

			return false;
		}

	}

	public class MyOverlay extends Overlay {

		private ShapeRecord record;

		private Context context;

		private ZDXM zdxm;

		private DataBaseHelper helper;

		private Bounds bounds;

		public Bounds getBounds() {
			if (bounds == null) {
				GeoPoint point = record.getGeoPoints().get(0);
				int x1 = point.getLatitudeE6(), x2 = x1, y1 = point
						.getLongitudeE6(), y2 = y1;

				for (GeoPoint geoPoint : record.getGeoPoints()) {
					x1 = Math.min(x1, geoPoint.getLatitudeE6());
					x2 = Math.max(x2, geoPoint.getLatitudeE6());
					y1 = Math.min(y1, geoPoint.getLongitudeE6());
					y2 = Math.max(y2, geoPoint.getLongitudeE6());
				}
				bounds = new Bounds(x1, x2, y1, y2);
			}

			return bounds;
		}

		public ZDXM getZdxm() {
			if (zdxm == null) {
				try {
					zdxm = helper.getZDXMDao()
							.queryForId(record.getPROJECTID());
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return zdxm;
		}
		
		private Paint paint = new Paint();
		
		private Bitmap bitmap;

		public MyOverlay(Context context, ShapeRecord record) {
			super();
			bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.repeat_line);
			helper = new DataBaseHelper(context);
			this.context = context;
			this.record = record;
			paint.setAntiAlias(true);
			paint.setStrokeWidth(2);
			paint.setAlpha(0);
			paint.setColor(Color.RED);
			paint.setStyle(Style.STROKE);
		}

		@Override
		public void draw(Canvas canvas, MapView mapView, boolean shadow) {
			// TODO Auto-generated method stub
			super.draw(canvas, mapView, shadow);
			Point[] pointScr = convertPoints(mapView.getProjection(),
					record.getGeoPoints());
			
			
			Path path = new Path();
			path.moveTo(pointScr[0].x, pointScr[0].y);
			for (int i = 1; i < pointScr.length; i++) {
				path.lineTo(pointScr[i].x, pointScr[i].y);
			}
			ShapeDrawable mDrawable = new ShapeDrawable(new PathShape(path, 250, 250));
			Shader aShader = new BitmapShader(bitmap, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
			mDrawable.getPaint().setShader(aShader);
			canvas.drawPath(path, paint);
			mDrawable.setBounds(0,0,250,250); 
			mDrawable.draw(canvas);
			path.reset();
		}

		private Point[] convertPoints(Projection prj, ArrayList<GeoPoint> points) {
			Point[] ptsRet = new Point[points.size()];
			for (int i = 0; i < ptsRet.length; i++) {
				ptsRet[i] = prj.toPixels(points.get(i), null);
			}
			return ptsRet;
		}

		@Override
		public boolean onTap(GeoPoint arg0, MapView arg1) {

			Bounds bounds = getBounds();
			if (bounds.reject(arg0.getLatitudeE6(), arg0.getLongitudeE6())) {
				ZDXM zdxm = getZdxm();
				popup(context, zdxm.PK, zdxm.XMMC, arg0);
				return true;
			}

			return super.onTap(arg0, arg1);
		}

	}
	
	public ArrayList<MyOverlay> getAllShapeOverlay(Context context) throws SQLException{
		return getShapeOverlay("",context);
	}
	
	public ArrayList<MyOverlay> getShapeOverlay(String where,Context context) throws SQLException{
		ArrayList<MyOverlay> overlays = new ArrayList<MyOverlay>();
		DataBaseHelper baseHelper = new DataBaseHelper(context);
		
		
		
		String query = "select zdxm.PK,zdxm.XMMC,shape.points from (select PK,XMMC from ZDXM "+where+" ) zdxm  join (select PROJECTID,points from ShapeRecord) shape on (zdxm.PK=shape.PROJECTID)";
		GenericRawResults<String[]> results = baseHelper.getShapeRecordDao().queryRaw(query);
		for(String[] row : results.getResults()){
			overlays.add(new MyOverlay(context, new ShapeRecord(row[0], row[1],row[2])));
		}
		return overlays;
	}

	public class OverItemT extends ItemizedOverlay<OverlayItem> {

		private List<PointRecord> records;

		private Context context;

		public OverItemT(Context context, List<PointRecord> records,
				Drawable marker) {
			super((boundCenterBottom(marker)));
			this.records = records;
			this.context = context;
			populate();
		}

		@Override
		protected OverlayItem createItem(int arg0) {
			PointRecord record = records.get(arg0);
			return new OverlayItem(new GeoPoint(record.getX(), record.getY()),
					record.getName(), record.getName());
		}

		@Override
		public int size() {
			// TODO Auto-generated method stub
			return records.size();
		}

		protected boolean onTap(final int i) {
			PointRecord record = records.get(i);
			GeoPoint pt = new GeoPoint(record.getX(), record.getY());
			popup(context, record.getUID(), record.getName(), pt);

			return true;
		}

		@Override
		public boolean onTap(GeoPoint p, MapView mapView) {
			// TODO Auto-generated method stub
			mPopView.setVisibility(View.GONE);
			return super.onTap(p, mapView);
		}

	}
	
}
