package com.chinadci.online.app.network.model;



import android.content.Context;
import android.content.SharedPreferences;

public class Preferences {

	public static class Profile{
		
		private static final String NAME = "Profile";
		
		private SharedPreferences preferences;

		public Profile(Context context) {
			preferences = context.getSharedPreferences(NAME, 0);
		}
		
		public void setInit(boolean val){
			preferences.edit().putBoolean("init", val).commit();
		}
		
		public boolean isInit(){
			return preferences.getBoolean("init", false);
		}
		
		public void setZDXMLastUpdate(String val){
			preferences.edit().putString("ZDXMLastUpdate", val).commit();
		}
		
		public String getZDXMLastUpdate(){
			return preferences.getString("ZDXMLastUpdate","1920-05-16 17:16:06");
		}
		
		public void setXMFJZLLastUpdate(String val){
			preferences.edit().putString("XMFJZLLastUpdate", val).commit();
		}
		
		public String getXMFJZLLastUpdate(){
			return preferences.getString("XMFJZLLastUpdate","1920-05-16 17:16:06");
		}
		
		
		public void setXMLNJHLastUpdate(String val){
			preferences.edit().putString("XMLNJHLastUpdate", val).commit();
		}
		
		public String getXMLNJHLastUpdate(){
			return preferences.getString("XMLNJHLastUpdate","1920-05-16 17:16:06");
		}
		
		public void setDSJSPLastUpdate(String val){
			preferences.edit().putString("DSJSPLastUpdate", val).commit();
		}
		
		public String getDSJSPLastUpdate(){
			return preferences.getString("DSJSPLastUpdate","1920-05-16 17:16:06");
		}
		public void setXMZXJZLastUpdate(String val){
			preferences.edit().putString("XMZXJZLastUpdate", val).commit();
		}
		
		public String getXMZXJZLastUpdate(){
			return preferences.getString("XMZXJZLastUpdate","1920-05-16 17:16:06");
		}
		
		public void setZLKLastUpdate(String val){
			preferences.edit().putString("ZLKLastUpdate", val).commit();
		}
		
		public String getZLKLastUpdate(){
			return preferences.getString("ZLKLastUpdate","1920-05-16 17:16:06");
		}
		
		public void setXMDSJLastUpdate(String val){
			preferences.edit().putString("XMDSJLastUpdate", val).commit();
		}
		
		public String getXMDSJLastUpdate(){
			return preferences.getString("XMDSJLastUpdate","1920-05-16 17:16:06");
		}
		public void setXMXCLastUpdate(String val){
			preferences.edit().putString("XMXCLastUpdate", val).commit();
		}
		
		public String getXMXCLastUpdate(){
			return preferences.getString("XMXCLastUpdate","1920-05-16 17:16:06");
		}
		
		public void setShapeLastUpdate(String val){
			preferences.edit().putString("ShapeLastUpdate", val).commit();
		}
		
		public String getShapeLastUpdate(){
			return preferences.getString("ShapeLastUpdate","1920-05-16 17:16:06");
		}
		
		public void setPointLastUpdate(String val){
			preferences.edit().putString("PointLastUpdate", val).commit();
		}
		
		public String getPointLastUpdate(){
			return preferences.getString("PointLastUpdate","1920-05-16 17:16:06");
		}
	
		
	}
}
