package com.chinadci.online.app.fragment;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import kankan.wheel.widget.OnWheelScrollListener;
import kankan.wheel.widget.WheelView;
import kankan.wheel.widget.adapters.ArrayWheelAdapter;

import com.chinadci.online.app.R;
import com.chinadci.online.app.adapter.ProjectListAdapter;
import com.chinadci.online.app.adapter.ProjectListAdapter.Project;
import com.chinadci.online.app.database.DataBaseHelper;
import com.chinadci.online.app.fragment.ProjectAllCurrentFragment.Status1;
import com.chinadci.online.app.network.Update;
import com.chinadci.online.app.network.model.ZDXM;
import com.chinadci.online.app.widget.BaseListView;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener;
import com.j256.ormlite.stmt.Where;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.ListView;
import android.widget.TextView;

public abstract class CommonItem1Fragment extends Fragment implements
		ICommonItemFragment, OnWheelScrollListener, OnClickListener {

	public enum Status1 {
		CURRENT, HISTORY
	}

	private WheelView wheelView;

	private TextView titlebar;

	private BaseListView listView;

	private ProjectListAdapter adapter;

	private List<Project> list = new ArrayList<ProjectListAdapter.Project>();

	private String[] whellList;

	protected DataBaseHelper helper;

	private String text;

	private TextView totalView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		helper = new DataBaseHelper(getActivity());

	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		return inflater.inflate(R.layout.common_fragment_item, null);
	}

	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onViewCreated(view, savedInstanceState);
		totalView = (TextView) view.findViewById(R.id.total);
		view.findViewById(R.id.arrow_icon).setVisibility(View.GONE);
		titlebar = (TextView) view.findViewById(R.id.titlebar);
		listView = (BaseListView) view.findViewById(R.id.listview);
		wheelView = (WheelView) view.findViewById(R.id.wheel);
		titlebar.setText("收藏项目");
		wheelView.setVisibility(View.GONE);

		adapter = new ProjectListAdapter(getActivity(), list);
		listView.setAdapter(adapter);
		listView.setOnRefreshListener(new OnRefreshListener<ListView>() {

			public void onRefresh(PullToRefreshBase<ListView> refreshView) {

				new Thread(new Runnable() {

					@Override
					public void run() {
						Update.update(getActivity());
						onChange();
					}
				}).start();

			}
		});

	}

	public void _onChange(String text) {
		this.text = text;
		onChange();
	}

	private void onChange() {
		new AsyncTask<Void, Void, List<Project>>() {

			@Override
			protected List<Project> doInBackground(Void... params) {

				List<ZDXM> res = new ArrayList<ZDXM>();

				res = onChange(text);

				return ZDXM.toProjectList(res);
			}

			@Override
			protected void onPostExecute(List<Project> result) {
				list.clear();
				list.addAll(result);
				adapter.notifyDataSetChanged();
				listView.onRefreshComplete();
				totalView.setText("" + list.size());

			}

		}.execute();
	}

	protected void buildStatus(Where where, Status1 status1)
			throws SQLException {

		if (status1 == Status1.CURRENT) {
			where.notIn("JSJD", "完工");
		} else {
			where.eq("JSJD", "完工");
		}
	}

	@Override
	public void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		onChange();
	}

	@Override
	public void onScrollingFinished(WheelView wheel) {
		String str = whellList[wheel.getCurrentItem()];
		titlebar.setText(str);
		_onChange(str);

	}

	@Override
	public void onScrollingStarted(WheelView wheel) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onClick(View v) {

	}

}
