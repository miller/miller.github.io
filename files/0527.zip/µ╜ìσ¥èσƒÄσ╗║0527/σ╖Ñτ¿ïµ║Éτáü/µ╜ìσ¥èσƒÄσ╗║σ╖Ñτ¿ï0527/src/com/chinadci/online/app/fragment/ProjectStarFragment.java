package com.chinadci.online.app.fragment;

import java.sql.SQLException;
import java.util.List;

import com.chinadci.online.app.network.model.ZDXM;

import android.content.Context;
import android.support.v4.app.Fragment;

public class ProjectStarFragment extends CommonFragment{



	@Override
	protected Fragment createFragment(int args) {
		Fragment fragment = null;
		switch (args) {
		case 0:
			fragment = new ProjectStarCurrentFragment();
			break;
		case 1:
			fragment = new ProjectStarHistoryFragment();
			break;
		default:
			break;
		}
		return fragment;
	}

	@Override
	protected int countFragment() {
		// TODO Auto-generated method stub
		return 2;
	}


	

}
