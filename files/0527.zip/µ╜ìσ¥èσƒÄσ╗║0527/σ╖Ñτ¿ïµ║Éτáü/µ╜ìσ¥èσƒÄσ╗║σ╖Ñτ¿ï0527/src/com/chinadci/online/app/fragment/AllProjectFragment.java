package com.chinadci.online.app.fragment;




import com.chinadci.online.app.R;
import com.chinadci.online.app.fragment.ProjectAllCurrentFragment.Status1;
import com.chinadci.online.app.utils.WigetUtils;
import com.chinadci.online.app.utils.WigetUtils.OnItemClickListener;



import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

public class AllProjectFragment extends Fragment implements OnPageChangeListener,OnItemClickListener{

	public static AllProjectFragment newInstance(){
		return new AllProjectFragment();
	}
	
	private EditText editText;
	
	private ViewPager viewPager;
	
	private ViewGroup group;
	
	private View lastView;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		return inflater.inflate(R.layout.all_project_layout, null);
	}
	
	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onViewCreated(view, savedInstanceState);
		editText = (EditText) view.findViewById(R.id.search);
		viewPager = (ViewPager) view.findViewById(R.id.pager);
		viewPager.setAdapter(new MyAdapter());
		viewPager.setOnPageChangeListener(this);
		group = (ViewGroup)view.findViewById(R.id.common_tab);
		WigetUtils.onChildViewClick(group, this);
		group.getChildAt(0).performClick();
	}
	
	private class MyAdapter extends FragmentPagerAdapter{

		
		
		public MyAdapter() {
			super(getChildFragmentManager());
			// TODO Auto-generated constructor stub
		}

		@Override
		public Fragment getItem(int arg0) {
			Fragment fragment = null;
			switch (arg0) {
			case 0:
				fragment = ProjectAllCurrentFragment.newInstance(editText, Status1.CURRENT);
				break;
			case 1:
				fragment  =ProjectAllCurrentFragment.newInstance(editText, Status1.HISTORY);
				break;
			default:
				break;
			}
			return fragment;
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return 2;
		}
		
	}

	@Override
	public void onItemClick(ViewGroup group, View view, int position, long id) {
		if(lastView != null){
			lastView.setSelected(false);
		}
		view.setSelected(true);
		viewPager.setCurrentItem(position);
		lastView = view;
		
	}

	@Override
	public void onPageScrollStateChanged(int arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onPageScrolled(int arg0, float arg1, int arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onPageSelected(int arg0) {
		group.getChildAt(arg0).performClick();
		
	}
	
	
	
}
