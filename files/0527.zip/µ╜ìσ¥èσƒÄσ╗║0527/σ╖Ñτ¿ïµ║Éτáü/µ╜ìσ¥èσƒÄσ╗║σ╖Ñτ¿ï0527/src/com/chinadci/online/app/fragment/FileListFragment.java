package com.chinadci.online.app.fragment;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.IOFileFilter;
import org.apache.commons.io.filefilter.TrueFileFilter;

import com.chinadci.online.app.R;
import com.chinadci.online.app.adapter.FileListAdapter;
import com.chinadci.online.app.adapter.FileListAdapter.FileModel;
import com.chinadci.online.app.adapter.FileListAdapter.FileType;
import com.chinadci.online.app.utils.Configuration;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener;
import com.handmark.pulltorefresh.library.PullToRefreshListView;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.widget.ListView;

public class FileListFragment extends Fragment implements IOFileFilter,TextWatcher,OnItemClickListener{
	
	public static FileListFragment newInstance(){
		return new FileListFragment();
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		return inflater.inflate(R.layout.filelist_layout, null);
	}
	
	private EditText searchText;
	
	private PullToRefreshListView listView;
	
	private FileListAdapter adapter;
	
	private List<FileModel> list = new ArrayList<FileListAdapter.FileModel>();
	
	private String search;
	
	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onViewCreated(view, savedInstanceState);
		searchText = (EditText) view.findViewById(R.id.search);
		search = searchText.getText().toString();
		listView = (PullToRefreshListView) view.findViewById(R.id.listview);
		listView.getRefreshableView().setOnItemClickListener(this);
		adapter = new FileListAdapter(getActivity(), list);
		listView.setAdapter(adapter);
		listView.setOnRefreshListener(new OnRefreshListener<ListView>() {

			@Override
			public void onRefresh(PullToRefreshBase<ListView> refreshView) {
				
				refresh();
			}
		});
		searchText.addTextChangedListener(this);
		refresh();
	}
	
	
	
	private void refresh(){
		new AsyncTask<Void, Void, List<FileModel>>(){

			@Override
			protected List<FileModel> doInBackground(Void... params) {
				List<FileModel> models = new ArrayList<FileListAdapter.FileModel>();
				Iterator<File> itor = FileUtils.iterateFilesAndDirs(Configuration.FILE_LOCAL , FileListFragment.this, TrueFileFilter.TRUE);
				while(itor.hasNext()){
					File file = itor.next();
					FileType fileType = FileModel.getFileType(getExtend(file.getName()));
					if(fileType != null){
						FileModel model = new FileModel(file.toString(), file.getName(),fileType );
						models.add(model);
					}
					
					
				}
				return models;
			}
			
			protected void onPostExecute(List<FileModel> result) {
				list.clear();
				list.addAll(result);
				adapter.notifyDataSetChanged();
				listView.onRefreshComplete();
			};
			
		}.execute();
		
		
	}
	
	

	private List<String> extendlist = Arrays.asList(new String[]{"jpg","jpeg","doc","docx","xls","xlsx","pdf","mp4","mp3","gif","png","txt"});
	
	private String getExtend(String file){
		String extend = "";
		int index = file.lastIndexOf(".");
		if(index != -1){
			extend = file.substring(index+1, file.length());
		}
		return extend;
	}
	
	@Override
	public boolean accept(File file) {
		String name = file.getName().toString().toLowerCase();
		String extend = getExtend(name);
		search = search.toLowerCase();
		if(name.indexOf(search) != -1 && extendlist.indexOf(extend)!=-1){
			return true;
		}
		
		
		return false;
	}

	@Override
	public boolean accept(File dir, String name) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void afterTextChanged(Editable s) {
		search = s.toString();
		refresh();
		
	}

	@Override
	public void beforeTextChanged(CharSequence s, int start, int count,
			int after) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onTextChanged(CharSequence s, int start, int before, int count) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		FileModel model = list.get(arg2-1);
		model.getType().open(getActivity(), model.getUrl());
		
	}
	
	
	
	
	
}
