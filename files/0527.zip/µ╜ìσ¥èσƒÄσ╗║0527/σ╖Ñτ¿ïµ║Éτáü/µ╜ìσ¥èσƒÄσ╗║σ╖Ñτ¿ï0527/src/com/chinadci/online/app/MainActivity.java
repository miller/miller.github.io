package com.chinadci.online.app;

import com.chinadci.online.app.fragment.AllProjectFragment;
import com.chinadci.online.app.fragment.FileListFragment;
import com.chinadci.online.app.fragment.ProjectLeibieFragment;
import com.chinadci.online.app.fragment.ProjectStarFragment;
import com.chinadci.online.app.fragment.ProjectYearFragment;
import com.chinadci.online.app.fragment.ProjectZRDWFragment;
import com.chinadci.online.app.fragment.ProjectZRRFragment;
import com.chinadci.online.app.network.Update;
import com.chinadci.online.app.network.model.Preferences;
import com.chinadci.online.app.widget.DispatchFrameLayout;
import com.chinadci.online.app.widget.DispatchFrameLayout.OnDispatchTouchEvent;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.Toast;

public class MainActivity extends FragmentActivity implements OnClickListener {

	private View lastView;
	
	private View moreBar;

	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main_activity);
		((DispatchFrameLayout)findViewById(R.id.frame_content)).setOnDispatchTouchEvent(new OnDispatchTouchEvent() {
			
			@Override
			public boolean dispatchTouchEvent(MotionEvent ev) {
				moreBar.setVisibility(View.GONE);
				return false;
			}
		});
		
		
		moreBar = findViewById(R.id.more_bar);
		findViewById(R.id.tab1).setOnClickListener(this);
		findViewById(R.id.tab2).setOnClickListener(this);
		findViewById(R.id.tab3).setOnClickListener(this);
		findViewById(R.id.tab4).setOnClickListener(this);
		findViewById(R.id.tab_star).setOnClickListener(this);
		findViewById(R.id.tab_year).setOnClickListener(this);
		findViewById(R.id.tab_file).setOnClickListener(this);
		findViewById(R.id.tab_more).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				moreBarSwitch();
			}
		});
		final Preferences.Profile profile = new Preferences.Profile(this);
		if(!profile.isInit()){
			final ProgressDialog dialog = ProgressDialog.show(this, "提示", "正在更新数据 ...",true);
			new AsyncTask() {

				@Override
				protected Object doInBackground(Object... params) {
					Update.update(MainActivity.this);
					return null;
				}
				
				protected void onPostExecute(Object result) {
					profile.setInit(true);
					dialog.dismiss();
					findViewById(R.id.tab1).performClick();
				};
				
			}.execute();
		}else{
			findViewById(R.id.tab1).performClick();
		}
		
		
	}
	
	private void moreBarSwitch(){
		if(moreBar.getVisibility()==View.VISIBLE){
			moreBar.setVisibility(View.GONE);
		}else{
			moreBar.setVisibility(View.VISIBLE);
		}
	}
	
	private Fragment[] fragments = new Fragment[]{
		AllProjectFragment.newInstance(),
		new ProjectLeibieFragment(),
		new ProjectZRRFragment(),
		new ProjectZRDWFragment(),
		new ProjectStarFragment(),
		new FileListFragment(),
		new ProjectYearFragment()
	};

	@Override
	public void onClick(View v) {
		if (lastView != null) {
			lastView.setSelected(false);
		}
		moreBar.setVisibility(View.GONE);
		v.setSelected(true);
		switch (v.getId()) {
		case R.id.tab1:
			switchFragment(AllProjectFragment.newInstance());
			break;
		case R.id.tab2:
			switchFragment(new ProjectLeibieFragment());
			break;
		case R.id.tab3:
			switchFragment(new ProjectZRRFragment());
			break;
		case R.id.tab4:
			switchFragment(new ProjectZRDWFragment());
			break;
		case R.id.tab_star:
			switchFragment(new ProjectStarFragment());
			break;
		case R.id.tab_file:
			switchFragment(new FileListFragment());
			break;
		case R.id.tab_year:
			switchFragment(new ProjectYearFragment());
			break;
		
		/*case R.id.tab1:
			switchFragment(fragments[0]);
			break;
		case R.id.tab2:
			switchFragment(fragments[1]);
			break;
		case R.id.tab3:
			switchFragment(fragments[2]);
			break;
		case R.id.tab4:
			switchFragment(fragments[3]);
			break;
		case R.id.tab_star:
			switchFragment(fragments[4]);
			break;
		case R.id.tab_file:
			switchFragment(fragments[5]);
			break;
		case R.id.tab_year:
			switchFragment(fragments[6]);
			break;*/
		}

		lastView = v;

	}
	
	private Fragment lastFragment;

	public void switchFragment(Fragment fragment) {
		getSupportFragmentManager().beginTransaction().replace(R.id.frame_content,fragment).commit();
		/*FragmentManager fm = getSupportFragmentManager();
		FragmentTransaction transaction = fm.beginTransaction();
		if(lastFragment != null){
			transaction.hide(lastFragment);
		}
		if(!fragment.isAdded()){
			transaction.add(R.id.frame_content,fragment);
		}else{
			transaction.show(fragment);
			fragment.onResume();
		}
		transaction.commitAllowingStateLoss();
		lastFragment = fragment;*/
	}
	
	private long currentBackPressedTime = 0;

	private static final int BACK_PRESSED_INTERVAL = 2000;
	
	@Override
	public void onBackPressed() {
		// 判断时间间隔
		if (System.currentTimeMillis() - currentBackPressedTime > BACK_PRESSED_INTERVAL) {
			currentBackPressedTime = System.currentTimeMillis();
			Toast.makeText(this, "再按一次返回键退出程序", Toast.LENGTH_SHORT).show();
		} else {
			// 退出
			finish();
		}
	}
	

}
