package com.chinadci.online.app;

import com.chinadci.online.app.fragment.AllProjectFragment;
import com.chinadci.online.app.fragment.ProjectLeibieFragment;

import android.app.Activity;
import android.os.Bundle;

public class Tab2Activity extends BaseActivity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		switchFragment("all",new ProjectLeibieFragment());
	}
	
}
