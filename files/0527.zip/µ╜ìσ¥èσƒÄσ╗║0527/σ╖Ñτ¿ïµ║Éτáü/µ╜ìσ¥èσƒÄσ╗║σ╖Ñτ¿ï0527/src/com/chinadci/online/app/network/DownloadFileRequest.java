package com.chinadci.online.app.network;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.commons.io.FilenameUtils;

import com.chinadci.online.app.utils.Configuration;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Environment;

public class DownloadFileRequest {

	
	private Context context;
	
	private String url;
	
	private Callback callback;
	
	
	
	public static interface Callback{
		public void onload(File file);
	}
	
	
	
	public DownloadFileRequest(Context context, String url, Callback callback) {
		super();
		this.context = context;
		this.url = url;
		this.callback = callback;
	}

	public void download(){
		final ProgressDialog dialog = ProgressDialog.show(context, "提示", "正在下载...",true);
		new AsyncTask<Void, Void, File>() {

			@Override
			protected File doInBackground(Void... params) {
				String name = ""+url.hashCode();
				File file =  new File(Configuration.FILE_LOCAL,name);
				if(file.exists()){
					return file;
				}
				download2(url, file.toString());
				return file;
			}
			
			protected void onPostExecute(File file) {
				dialog.dismiss();
				callback.onload(file);
			};
			
		}.execute();
		
		
	}
	
	private void download2(String strurl,String filename){
		InputStream input = null;
        OutputStream output = null;
        HttpURLConnection connection = null;
        try {
            URL url = new URL(strurl);
            connection = (HttpURLConnection) url.openConnection();
            connection.connect();

            // expect HTTP 200 OK, so we don't mistakenly save error report
            // instead of the file
            if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
                System.err.println("Server returned HTTP " + connection.getResponseCode()
                        + " " + connection.getResponseMessage()) ;
                return;
            }

            // download the file
            input = connection.getInputStream();
            File file = new File(filename);
            if(!file.exists()){
            	file.createNewFile();
            }
            output = new FileOutputStream( file);

            byte data[] = new byte[4096];
            int count;
            while ((count = input.read(data)) != -1) {
                // allow canceling with back button
              
              
               
                output.write(data, 0, count);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (output != null)
                    output.close();
                if (input != null)
                    input.close();
            } catch (IOException ignored) {
            }

            if (connection != null)
                connection.disconnect();
        }
	}
	
	

}
