package com.chinadci.online.app.network;

public interface IRequest {

	public void request();
	
}
