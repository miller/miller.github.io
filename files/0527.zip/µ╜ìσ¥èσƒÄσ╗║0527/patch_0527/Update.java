package com.chinadci.online.app.network;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.chinadci.online.app.database.DataBaseHelper;
import com.chinadci.online.app.network.ZDXMRequest.Params;
import com.chinadci.online.app.network.model.DSJSP;
import com.chinadci.online.app.network.model.GeoFileDownloadRequest;
import com.chinadci.online.app.network.model.PointRecord;
import com.chinadci.online.app.network.model.Preferences;
import com.chinadci.online.app.network.model.ShapeRecord;
import com.chinadci.online.app.network.model.XMDSJ;
import com.chinadci.online.app.network.model.XMFJZL;
import com.chinadci.online.app.network.model.XMLNJH;
import com.chinadci.online.app.network.model.XMXC;
import com.chinadci.online.app.network.model.XMZXJZ;
import com.chinadci.online.app.network.model.ZDXM;
import com.chinadci.online.app.network.model.ZLK;
import com.chinadci.online.app.utils.Configuration;
import com.tianditu.android.maps.GeoPoint;

import diewald_shapeFile.files.dbf.DBF_File;
import diewald_shapeFile.files.shp.SHP_File;
import diewald_shapeFile.files.shp.shapeTypes.ShpPoint;
import diewald_shapeFile.files.shp.shapeTypes.ShpPolygon;
import diewald_shapeFile.files.shx.SHX_File;
import diewald_shapeFile.shapeFile.ShapeFile;

import android.content.Context;
import android.text.TextUtils;

public class Update {

	static {
		DBF_File.LOG_INFO = false;
		DBF_File.LOG_ONLOAD_CONTENT = false;
		DBF_File.LOG_ONLOAD_HEADER = false;
		SHP_File.LOG_INFO = false;
		SHP_File.LOG_ONLOAD_CONTENT = false;
		SHP_File.LOG_ONLOAD_HEADER = false;
		SHX_File.LOG_INFO = !false;
		SHX_File.LOG_ONLOAD_CONTENT = false;
		SHX_File.LOG_ONLOAD_HEADER = false;
	}
	
	public static void update(Context context){
		ZDXMUpdate(context);
		XMXCUpdate(context);
		XMFJZLUpdate(context);
		ZLKUpdate(context);
		XMDSJUpdate(context);
		XMZXJZUpdate(context);
		DSJSPUpdate(context);
		XMFJZLUpdate(context);
		GeoFileUpdate(context);
		
	}
	
	public static void GeoFileUpdate(Context context){
		
		GeoFileDownloadRequest request = new GeoFileDownloadRequest();
		request.download(context);
		try {
			importGeoPoint(context);
			importGeoShape(context);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static void importGeoPoint(Context context) throws Exception{
		ShapeFile sf = new ShapeFile(Configuration.FOLDER.toString(), "zdxm_point").READ();
		DataBaseHelper helper = new DataBaseHelper(context);
		for(int i = 0;i<sf.getDBF_recordCount();i++){
			String id = StringUtils.trim(sf.getDBF_record(i, 30));
			if(!TextUtils.isEmpty(id)){
				ShpPoint point =  sf.getSHP_shape(i);
				PointRecord pointRecord = new PointRecord(id, (int)(point.getPoint()[1]*1E6),(int)(point.getPoint()[0]*1E6));
				helper.getPointRecordDao().createOrUpdate(pointRecord);
			}
			
		}
	}
	
	private static void importGeoShape(Context context) throws Exception{
		ShapeFile sf = new ShapeFile(Configuration.FOLDER.toString(), "zdxm_polygon").READ();
		DataBaseHelper helper = new DataBaseHelper(context);
		for(int i = 0;i<sf.getDBF_recordCount();i++){
			String id = StringUtils.trim(sf.getDBF_record(i, 0));
			if(!TextUtils.isEmpty(id)){
				ShpPolygon polygon =  sf.getSHP_shape(i);
				ArrayList<GeoPoint> geoPoints = new ArrayList<GeoPoint>();
				for(double[] row : polygon.getPoints()){
					geoPoints.add(new GeoPoint((int)(row[1]*1E6), (int)(row[0]*1E6)));
				}
				ShapeRecord record = new ShapeRecord(id, geoPoints);
				helper.getShapeRecordDao().createOrUpdate(record);
			}
			
		}
	}
	
	public static void ZDXMUpdate(Context context){
		ZDXMUpdate(context,null);
	}
	private static void ZDXMUpdate(Context context,String time){
		Preferences.Profile profile = new Preferences.Profile(context);
		if(time == null){
			
			time = profile.getZDXMLastUpdate();
		}
		
		
		ZDXMRequest request = new ZDXMRequest(new Params(time));
		request.request();

		DataBaseHelper helper = new DataBaseHelper(context);
		for(ZDXM zdxm:request.getList()){
			try {
				if(!"1".equals(StringUtils.trim(zdxm.ISDELETE))){
					helper.getZDXMDao().createOrUpdate(zdxm);
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		if(request.getList().size()>0){
			ZDXM last = request.getList().get(request.getList().size()-1);
			profile.setZDXMLastUpdate(last.LASTUPDATE);
			ZDXMUpdate(context, last.LASTUPDATE);
		}
		
	}
	
	public static void XMFJZLUpdate(Context context){
		XMFJZLUpdate(context,null);
	}
	private static void XMFJZLUpdate(Context context,String time){
		Preferences.Profile profile = new Preferences.Profile(context);
		if(time == null){
			time = profile.getXMFJZLLastUpdate();
		}
		
		
		XMFJZLRequest request = new XMFJZLRequest(new XMFJZLRequest.Params(time));
		request.request();

		DataBaseHelper helper = new DataBaseHelper(context);
		for(XMFJZL zdxm:request.getList()){
			try {
				if(!"1".equals(StringUtils.trim(zdxm.ISDELETE))){
					helper.getXMFJZLDao().createOrUpdate(zdxm);
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		if(request.getList().size()>0){
			XMFJZL last = request.getList().get(request.getList().size()-1);
			profile.setXMFJZLLastUpdate(last.LASTUPDATE);
			XMFJZLUpdate(context, last.LASTUPDATE);
		}
		
	}
	
	public static void DSJSPUpdate(Context context){
		DSJSPUpdate(context,null);
	}
	private static void DSJSPUpdate(Context context,String time){
		Preferences.Profile profile = new Preferences.Profile(context);
		if(time == null){
			time = profile.getDSJSPLastUpdate();
		}
		
		
		DSJSPRequest request = new DSJSPRequest(new DSJSPRequest.Params(time));
		request.request();

		DataBaseHelper helper = new DataBaseHelper(context);
		for(DSJSP zdxm:request.getList()){
			try {
				if(!"1".equals(StringUtils.trim(zdxm.ISDELETE))){
					helper.getDSJSPDao().createOrUpdate(zdxm);
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		if(request.getList().size()>0){
			DSJSP last = request.getList().get(request.getList().size()-1);
			profile.setDSJSPLastUpdate(last.LASTUPDATE);
			DSJSPUpdate(context, last.LASTUPDATE);
		}
		
	}
	
	public static void XMLNJHUpdate(Context context){
		XMLNJHUpdate(context,null);
	}
	private static void XMLNJHUpdate(Context context,String time){
		Preferences.Profile profile = new Preferences.Profile(context);
		if(time == null){
			time = profile.getXMLNJHLastUpdate();
		}
		
		
		XMLNJHRequest request = new XMLNJHRequest(new XMLNJHRequest.Params(time));
		request.request();

		DataBaseHelper helper = new DataBaseHelper(context);
		for(XMLNJH zdxm:request.getList()){
			try {
				if(!"1".equals(StringUtils.trim(zdxm.ISDELETE))){
					helper.getXMLNJHDao().createOrUpdate(zdxm);
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		if(request.getList().size()>0){
			XMLNJH last = request.getList().get(request.getList().size()-1);
			profile.setZDXMLastUpdate(last.LASTUPDATE);
			XMLNJHUpdate(context, last.LASTUPDATE);
		}
		
	}
	
	
	public static void XMZXJZUpdate(Context context){
		XMZXJZUpdate(context,null);
	}
	private static void XMZXJZUpdate(Context context,String time){
		Preferences.Profile profile = new Preferences.Profile(context);
		if(time == null){
			time = profile.getXMZXJZLastUpdate();
		}
		
		
		XMZXJZRequest request = new XMZXJZRequest(new XMZXJZRequest.Params(time));
		request.request();

		DataBaseHelper helper = new DataBaseHelper(context);
		for(XMZXJZ zdxm:request.getList()){
			try {
				if(!"1".equals(StringUtils.trim(zdxm.ISDELETE))){
					helper.getXMZXJZDao().createOrUpdate(zdxm);
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		if(request.getList().size()>0){
			XMZXJZ last = request.getList().get(request.getList().size()-1);
			profile.setXMZXJZLastUpdate(last.LASTUPDATE);
			XMZXJZUpdate(context, last.LASTUPDATE);
		}
		
	}
	
	public static void ZLKUpdate(Context context){
		ZLKUpdate(context,null);
	}
	private static void ZLKUpdate(Context context,String time){
		if(context == null){
			return;
		}
		Preferences.Profile profile = new Preferences.Profile(context);
		if(time == null){
			time = profile.getZLKLastUpdate();
		}
		
		
		ZLKRequest request = new ZLKRequest(new ZLKRequest.Params(time));
		request.request();

		DataBaseHelper helper = new DataBaseHelper(context);
		for(ZLK zdxm:request.getList()){
			try {
				if(!"1".equals(StringUtils.trim(zdxm.ISDELETE))){
					helper.getZLKDao().createOrUpdate(zdxm);
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		if(request.getList().size()>0){
			ZLK last = request.getList().get(request.getList().size()-1);
			profile.setZLKLastUpdate(last.LASTUPDATE);
			ZLKUpdate(context, last.LASTUPDATE);
		}
		
	}
	
	public static void XMDSJUpdate(Context context){
		XMDSJUpdate(context,null);
	}
	
	private static void XMDSJUpdate(Context context,String time){
		Preferences.Profile profile = new Preferences.Profile(context);
		if(time == null){
			time = profile.getXMDSJLastUpdate();
		}
		
		
		XMDSJRequest request = new XMDSJRequest(new XMDSJRequest.Params(time));
		request.request();

		DataBaseHelper helper = new DataBaseHelper(context);
		for(XMDSJ zdxm:request.getList()){
			try {
				if(!"1".equals(StringUtils.trim(zdxm.ISDELETE))){
					helper.getXMDSJDao().createOrUpdate(zdxm);
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		if(request.getList().size()>0){
			XMDSJ last = request.getList().get(request.getList().size()-1);
			profile.setXMDSJLastUpdate(last.LASTUPDATE);
			XMDSJUpdate(context, last.LASTUPDATE);
		}
		
	}
	
	public static void XMXCUpdate(Context context){
		XMXCUpdate(context,null);
	}
	
	private static void XMXCUpdate(Context context,String time){
		if (context == null) {
			return;
		}
		Preferences.Profile profile = new Preferences.Profile(context);
		if(time == null){
			time = profile.getXMXCLastUpdate();
		}
		
		
		XMXCRequest request = new XMXCRequest(new XMXCRequest.Params(time));
		request.request();

		DataBaseHelper helper = new DataBaseHelper(context);
		for(XMXC zdxm:request.getList()){
			try {
				if(!"1".equals(StringUtils.trim(zdxm.ISDELETE))){
					helper.getXMXCDao().createOrUpdate(zdxm);
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		if(request.getList().size()>0){
			XMXC last = request.getList().get(request.getList().size()-1);
			profile.setXMXCLastUpdate(last.LASTUPDATE);
			XMXCUpdate(context, last.LASTUPDATE);
		}
		
	}
	

}
