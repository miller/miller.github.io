package com.chinadci.online.app.adapter;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FilenameUtils;

import com.chinadci.online.app.R;
import com.chinadci.online.app.SliderActivity;
import com.chinadci.online.app.network.Request;
import com.chinadci.online.app.utils.BitmapLoader;
import com.chinadci.online.app.utils.DisplayUtils;
import com.chinadci.online.app.utils.IntentUtils;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.assist.ImageLoadingListener;
import com.nostra13.universalimageloader.core.assist.ImageSize;
import com.nostra13.universalimageloader.core.assist.SimpleImageLoadingListener;

import android.content.Context;
import android.graphics.Bitmap;
import android.media.Image;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;

public class GalleryListAdapter extends BaseAdapter{

	public enum GalleryType {
		PIC, VIDEO
	}

	public static class GalleryModel implements Serializable{

		private GalleryType galleryType;

		private String pic;

		private String videourl;
		
		private boolean checked;

		public GalleryModel(String pic) {
			this.pic = pic;
			galleryType = GalleryType.PIC;
		}

		public GalleryModel(String videourl,String s) {
			super();
			this.videourl = videourl;
			galleryType = GalleryType.VIDEO;
		}
		
		public boolean isChecked() {
			return checked;
		}
		public GalleryType getGalleryType() {
			return galleryType;
		}
		public String getPic() {
			return pic;
		}
		public String getVideourl() {
			return videourl;
		}

	}
	
	private Context context;
	
	private List<GalleryModel> list;
	
	private boolean checked;
	
	private int size;

	public GalleryListAdapter(Context context, List<GalleryModel> list,boolean checked) {
		super();
		this.context = context;
		this.list = list;
		this.checked = checked;
		size = DisplayUtils.Dp2Px(context, 50);
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		final GalleryModel model = list.get(position);
		ViewHolder holder;
		if(convertView == null){
			convertView = LayoutInflater.from(context).inflate(
					R.layout.media_item, null);
			holder = new ViewHolder(convertView);
			convertView.setTag(holder);
		}else{
			holder = (ViewHolder) convertView.getTag();
		}
		
		final View loading = holder.loadingView;
		
		holder.picView.setImageBitmap(null);
		loading.setVisibility(View.GONE);
		if(model.galleryType == GalleryType.VIDEO){
			Bitmap bitmap = ThumbnailUtils.createVideoThumbnail(Uri.parse(model.videourl).getPath(),
	                MediaStore.Images.Thumbnails.MINI_KIND);
			if(bitmap != null){
				holder.picView.setImageBitmap(bitmap);
			}
			holder.videoView.setVisibility(View.VISIBLE);
		}else{
			
			final ImageView picView = holder.picView;
			loading.setVisibility(View.VISIBLE);
			BitmapLoader.getImageLoader(context).loadImage(model.pic, new ImageSize(size, size), new SimpleImageLoadingListener(){
				@Override
				public void onLoadingComplete(String imageUri, View view,
						Bitmap loadedImage) {
					loading.setVisibility(View.GONE);
					picView.setImageBitmap(loadedImage);
				}
			});
			
			holder.videoView.setVisibility(View.GONE);
		}
		holder.picView.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				ArrayList<GalleryListAdapter.GalleryModel> models = new ArrayList<GalleryListAdapter.GalleryModel>();
				for(GalleryModel model : list){
					if(model.getGalleryType() == GalleryType.PIC){
						models.add(model);
					}
				}
				int index = 0;
				for(int i = 0;i<models.size();i++){
					if(models.get(i) == model){
						index = i;
						break;
					}
				}
				
				SliderActivity.open(context, models,index);
				/*String name = FilenameUtils.getName(model.pic);
				IntentUtils.startImageActivity(context,name, Uri.parse(model.pic));*/
				
			}
		});
		holder.videoView.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
//				SliderActivity.open(context, (ArrayList<GalleryListAdapter.GalleryModel>)list,position);
				IntentUtils.startVideoActivity(context, Uri.parse(model.videourl));
				
			}
		});
		if(checked){
			holder.checkBox.setVisibility(View.VISIBLE);
			holder.checkBox.setChecked(model.checked);
			holder.checkBox.setOnCheckedChangeListener(new OnCheckedChangeListener() {
				
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					model.checked = isChecked;
					
				}
			});
		}else{
			holder.checkBox.setVisibility(View.GONE);
		}
		
		
		
		
		return convertView;
	}

	private class ViewHolder{
		private ImageView picView;
		private View videoView;
		private CheckBox checkBox;
		private View loadingView;
		public ViewHolder(View view) {
			checkBox = (CheckBox) view.findViewById(R.id.checked);
			picView = (ImageView) view.findViewById(R.id.img);
			videoView = view.findViewById(R.id.video);
			loadingView = view.findViewById(R.id.loading);
		}
	}
	
}
